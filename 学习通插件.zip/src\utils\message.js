/**
* 消息通信封装
* - Content Script <-> Background <-> Side Panel
* - 使用统一信封格式：{ type, payload,requestId }
*/
(function (global) {
'use strict';

const REQUEST_TIMEOUT = 30_000;

// 1. Content Script / Side Panel 主动发送请求
function send(type, payload) {
return new Promise((resolve,reject) => {
const requestId =`r_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
const timer = setTimeout(() => {
reject(new Error(`Message ${type} timeout`));
}, REQUEST_TIMEOUT);

chrome.runtime.sendMessage({ type, payload,requestId },response => {
clearTimeout(timer);
const err = chrome.runtime.lastError;
if (err)return reject(new Error(err.message));
if (response &&response.ok)resolve(response.data);
else reject(new Error(response?.error || 'unknown error'));
});
});
}

// 2. Background 监听
function listen(handlerMap) {
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
const { type, payload,requestId } = msg || {};
const handler = handlerMap[type];
if (!handler)return false; // 让其他监听器处理

Promise.resolve()
.then(() => handler(payload, sender))
.then(data => sendResponse({ ok: true, data,requestId }))
.catch(err => {
global.SALogger?.error('MSG',`handler ${type} failed:`, err);
sendResponse({ ok: false, error: err.message,requestId });
});
return true; // 保持异步通道
});
}

// 3. 长连接（用于流式输出）
function connect(name = 'sa-stream') {
  return chrome.runtime.connect({ name });
}

// 3b. 建立流式连接并发送初始请求
function connectStream(question, history) {
  const port = chrome.runtime.connect({ name: 'sa-stream' });
  port.postMessage({ type: 'start', question, history });
  return port;
}

// 4. 发送消息给指定 tab 的 content script（带超时）
function sendToTab(tabId, type, payload, timeoutMs = 15_000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Tab message timeout')), timeoutMs);
    chrome.tabs.sendMessage(tabId, { type, payload, requestId: 't_' + Date.now() }, resp => {
      clearTimeout(timer);
      const err = chrome.runtime.lastError;
      if (err) return reject(new Error(err.message));
      if (resp && resp.ok) resolve(resp.data);
      else reject(new Error(resp?.error || 'no response'));
    });
  });
}

// 5. 发送给当前活动 tab（Side Panel 常用）
async function sendToActiveTab(type, payload) {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) throw new Error('No active tab');
  return sendToTab(tab.id, type, payload);
}

global.SAMessage = { send, listen, connect, connectStream, sendToTab, sendToActiveTab };
})(typeof self !== 'undefined' ? self : globalThis);
