/**
* 适配器路由
* - 根据 host / path 选择合适的适配器
* - 兜底为 DefaultAdapter
*/
(function (global) {
'use strict';

const adapters = [
global.SAChaoxingAdapter,
global.SADefaultAdapter
].filter(Boolean);

const Router = {
match(host, path) {
for (const a of adapters) {
if (a.match(host, path))return a;
}
return global.SADefaultAdapter;
}
};

global.SAAdapterRouter = Router;
})(typeof self !== 'undefined' ? self : globalThis);
