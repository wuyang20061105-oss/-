/**
* 引擎抽象基类
*
* 子类需实现：
* - answer(question, history) : Promise<{ answer, steps?,raw? }>
* - streamAnswer(question, history, isAborted) : AsyncIterable<string>
*/
export class BaseEngine {
constructor(cfg) {
this.cfg = cfg;
}

/** 统一格式化：将 question 对象拼成 prompt */
buildPrompt(question, history = []) {
const lines = [];
if (question.stem) lines.push(`【题目】\n${question.stem}`);
if (question.type) lines.push(`【题型】${this.typeToZh(question.type)}`);
if (question.options?.length) {
lines.push('【选项】');
question.options.forEach(o => lines.push(`${o.key}. ${o.text}`));
}
lines.push('\n请直接给出答案与详细解析。如果存在多个合理选项，请按可能性排序。');
return lines.join('\n');
}

typeToZh(t) {
return { single: '单选', multiple: '多选', judge: '判断', fill: '填空', essay: '简答', 'user-selected': '选中文本', 'page-content': '网页内容', pdf: 'PDF 内容' }[t] || t;
}

async answer(_q, _h) { throw new Error('not implemented'); }
async *streamAnswer(_q, _h, _abort) { throw new Error('not implemented'); }
}
