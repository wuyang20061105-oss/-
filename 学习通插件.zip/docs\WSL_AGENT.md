﻿# WSL Agent 部署示例

> 在 WSL 内部署一个 Python HTTP 服务，对接任意 LLM 框架（Transformers / vLLM / Ollama / LangChain）。
> Windows 上的浏览器扩展通过`http://localhost:8787` 与之通信。

## 为什么需要 WSL Agent？
- 浏览器扩展的 CSP 严格，无法直接加载大型 Python 库
- WSL 可以跑**完整 Python 生态**：LangChain、LlamaIndex、向量数据库、工具调用
- 性能更好：WSL2 内存隔离，不会拖慢浏览器
- 跨平台统一：Mac/Linux/Windows 开发者都能用

## 架构

```
+---------------------+ HTTP +-----------------------+
| Chrome/Edge 扩展 | <------------> | WSL 内部 Python Agent |
| (service-worker.js) | localhost:8787| (FastAPI + vLLM/...) |
+---------------------+ +-----------------------+
|
v
抓取 / PDF / 学习通 DOM
```

## 快速开始（最小可运行示例）

### 1. 在 WSL 中准备环境

```bash
wsl # 进入 WSL
sudo apt update && sudo apt install python3-pip python3-venv -y
mkdir -p ~/study-agent && cd ~/study-agent
python3 -m venv .venv
source .venv/bin/activate
pip install fastapi uvicorn pydantic httpx
```

### 2. 拷贝`wsl_agent_demo.py` 到 WSL

把下面的`wsl_agent_demo.py` 文件复制到`~/study-agent/`。

### 3. 启动

```bash
uvicorn wsl_agent_demo:app --host 0.0.0.0 --port 8787
```

看到`Uvicornrunning on http://0.0.0.0:8787` 即成功。

### 4. 在浏览器扩展中配置

- 模式：**WSL Agent**
- Base URL：`http://localhost:8787`
- Agent 名称：`study-agent`
- 点「测试连接」应返回 200

> WSL2 启动后 Windows 通过`localhost` 即可访问，无需配置端口转发。
> 如果是 WSL1，需要把`localhost` 换成 WSL 的 eth0 IP。

---

## 进阶：接入真实 LLM

把`wsl_agent_demo.py` 中的 mock 替换为真实调用：

```python
# 方案 1：Ollama（最简单）
import httpx
OLLAMA = "http://localhost:11434"

async def call_llm(messages):
async with httpx.AsyncClient(timeout=60) as c:
r = await c.post(f"{OLLAMA}/api/chat", json={
"model": "qwen2.5:7b",
"messages": messages,
"stream": False
})
returnr.json()["message"]["content"]

# 方案 2：vLLM（生产级性能）
# pip install vllm
# vllm serve Qwen/Qwen2.5-7B-Instruct --port 8000
async def call_vllm(messages):
async with httpx.AsyncClient(timeout=60) as c:
r = await c.post("http://localhost:8000/v1/chat/completions", json={
"model": "Qwen/Qwen2.5-7B-Instruct",
"messages": messages
})
returnr.json()["choices"][0]["message"]["content"]

# 方案 3：LangChain + RAG
# from langchain.chat_models import ChatOpenAI
# from langchain.embeddings import OpenAIEmbeddings
# from langchain.vectorstores import Chroma
# ... 完整 RAG pipeline
```

---

## 进阶：添加工具调用（Agent）

参考 LangChain Agent 文档，把`/answer` 改造为支持`tools` 参数的 ReAct Agent。

常用工具：
- 搜索引擎（duckduckgo-search）
- 维基百科 API
- Wolfram Alpha（数学计算）
- 计算器
- 代码执行（Docker 沙箱）

---

## 故障排查

### WSL 中启动了，Windows 浏览器访问不到
- 检查 Windows 防火墙是否放行 8787
- 临时关闭：`netsh advfirewall set allprofiles state off`（**仅用于调试**）
- 改用`0.0.0.0` 绑定（uvicorn 默认就是）

### CORS 报错
浏览器扩展不属于跨域请求，**不需要 CORS**。如果使用 fetch 调试时遇到，加：
```python
from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(CORSMiddleware, allow_origins=["*"])
```

### 流式输出中断
检查nginx/uvicorn 的`proxy_read_timeout` 是否够长（默认 60s）。
