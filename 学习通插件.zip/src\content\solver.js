/**
 * AI 答题模块 (v3.0)
 * 
 * 三种模式：
 * - local:  Ollama 本地AI，自动检测可用模型，10分钟超时
 * - agent:  多端口自动探测，兼容 OpenCode / 自建Agent
 * - cloud:  云端AI（OpenAI / DeepSeek / 通义千问等）
 *
 * 统一接口：所有模式均走 OpenAI Chat Completions 协议
 * 
 * 题目检测：
 * - 弹窗内题目（测验弹窗）
 * - 页面内嵌入题目（iframe中的随堂测验）
 * - 支持穿透iframe提取题目
 */
(function (global) {
'use strict';

var STORAGE_KEY = 'sa_config_v1';

var AI_CONFIG = {
  timeout: 600000,
  refreshTimeout: 10000,
  agentPorts: [8787, 3000, 8080, 5000, 11434, 1234, 8000],
  cachedModels: [],
  selectedModel: '',
  agentEndpoint: ''
};

var _refreshed = false;

/* ==================== 选择器配置 ==================== */
var SEL = {
  /* 弹窗容器 */
  dialog: [
    '.topic-dialog', '.quiz-dialog', '.layui-layer-content',
    '[class*="topic"]', '.examBox', '.popups_box',
    '.layui-layer', '.el-dialog'
  ].join(', '),

  /* 题目容器 - 适配学习通多种页面结构 */
  question: [
    '.questionLi', '.singleQuesId', '.TiMu',
    '.question-item', '.topic', '.Zy_TItle',
    '.examTopic', '.questionBox'
  ].join(', '),

  /* 题目标题 */
  title: [
    'h3.mark_name', '.Zy_TItle .clearfix', '.topic-title',
    '.question-title', '.examTitle', '.TiMu > .title'
  ].join(', '),

  /* 选项容器 */
  option: [
    '.answerBg', '.Zy_ulTop li', '.topic-options li',
    '.option-list li', '.examOption', 'li[data]'
  ].join(', ')
};

function log() {
  var args = Array.prototype.slice.call(arguments);
  args.unshift('[AI]');
  console.log.apply(console, args);
}

function notify(msg) {
  try {
    window.top.postMessage({ action: 'SHOW_TOAST', msg: '[AI] ' + msg }, '*');
  } catch (e) {}
}

/* ==================== 配置读取 ==================== */
function getConfig() {
  return new Promise(function(resolve) {
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([STORAGE_KEY], function(result) {
        var stored = result[STORAGE_KEY];
        if (!stored) return resolve(getDefaults());
        resolve(merge(getDefaults(), stored));
      });
    } else {
      resolve(getDefaults());
    }
  });
}

function saveConfig(patch) {
  return new Promise(function(resolve) {
    getConfig().then(function(current) {
      var next = merge(current, patch);
      chrome.storage.local.set((function() { var o = {}; o[STORAGE_KEY] = next; return o; })(), function() {
        resolve(next);
      });
    });
  });
}

function getDefaults() {
  return {
    mode: 'local',
    local: { baseUrl: 'http://localhost:11434', apiKey: 'ollama', model: '', temperature: 0.2, maxTokens: 2048, systemPrompt: '' },
    cloud: { baseUrl: 'https://api.openai.com/v1', apiKey: '', model: 'gpt-4o-mini', temperature: 0.2, maxTokens: 2048, systemPrompt: '' },
    wsl:   { baseUrl: 'http://localhost:8787', apiKey: '', agentName: 'study-agent', timeoutMs: 600000 }
  };
}

function merge(target, source) {
  var result = {};
  for (var k in target) result[k] = target[k];
  for (var k in source) {
    if (source[k] && typeof source[k] === 'object' && !Array.isArray(source[k]) && result[k] && typeof result[k] === 'object') {
      result[k] = merge(result[k], source[k]);
    } else {
      result[k] = source[k];
    }
  }
  return result;
}

function getMode(cfg) { return cfg.mode || 'local'; }

/* ==================== 代理 fetch（绕过混合内容限制） ==================== */
function proxyFetch(url, options) {
  return new Promise(function(resolve, reject) {
    chrome.runtime.sendMessage(
      { type: 'proxy:fetch', payload: { url: url, options: options } },
      function(res) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!res) {
          reject(new Error('proxy fetch: no response'));
          return;
        }
        if (!res.ok) {
          reject(new Error('proxy fetch failed: ' + (res.error || res.status || 'unknown')));
          return;
        }
        resolve(res.body);
      }
    );
  });
}

/* ==================== 本地模型检测 ==================== */
async function detectOllamaModels(baseUrl) {
  try {
    var rootUrl = baseUrl.replace(/\/+$/, '').replace(/\/v1$/, '');
    var tagsUrl = rootUrl + '/api/tags';
    log('检测模型 URL: ' + tagsUrl);
    var data = await proxyFetch(tagsUrl, { method: 'GET' });
    if (!data || !data.models) {
      log('模型检测返回数据异常:', JSON.stringify(data).slice(0, 200));
      return [];
    }
    var models = data.models.map(function(m) { return m.name; });
    log('检测到 ' + models.length + ' 个本地模型:', models.join(', '));
    return models;
  } catch (e) {
    log('模型检测失败:', e.message);
    return [];
  }
}

async function ensureModel(cfg) {
  var baseUrl = (cfg.local || {}).baseUrl || 'http://localhost:11434';
  var configured = (cfg.local || {}).model || '';

  var models = await detectOllamaModels(baseUrl);
  AI_CONFIG.cachedModels = models;

  if (models.length === 0) {
    log('警告: 未检测到任何Ollama模型');
    notify('请先安装Ollama模型: ollama pull qwen2.5:7b');
    return null;
  }

  if (configured && models.indexOf(configured) !== -1) {
    AI_CONFIG.selectedModel = configured;
    return configured;
  }

  var preferred = ['qwen2.5:3b', 'qwen2.5:7b', 'qwen2.5:14b', 'qwen2.5:32b', 'gemma4:31b', 'llama3.1:8b', 'mistral:7b'];
  for (var i = 0; i < preferred.length; i++) {
    if (models.indexOf(preferred[i]) !== -1) {
      AI_CONFIG.selectedModel = preferred[i];
      log('自动选择模型: ' + preferred[i]);
      notify('自动选择模型: ' + preferred[i]);
      await saveConfig({ local: { model: preferred[i] } });
      return preferred[i];
    }
  }

  AI_CONFIG.selectedModel = models[0];
  log('使用首个可用模型: ' + models[0]);
  await saveConfig({ local: { model: models[0] } });
  return models[0];
}

/* ==================== Agent 多端口探测 ==================== */
async function probeAgentPort(port) {
  try {
    await proxyFetch('http://localhost:' + port + '/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'test', messages: [{ role: 'user', content: 'hi' }], max_tokens: 1 })
    });
    return true;
  } catch (e) {
    return false;
  }
}

async function detectAgentEndpoint() {
  if (AI_CONFIG.agentEndpoint) return AI_CONFIG.agentEndpoint;

  var ports = AI_CONFIG.agentPorts;
  log('开始探测Agent端口: ' + ports.join(', '));

  for (var i = 0; i < ports.length; i++) {
    var ok = await probeAgentPort(ports[i]);
    if (ok) {
      var endpoint = 'http://localhost:' + ports[i];
      AI_CONFIG.agentEndpoint = endpoint;
      log('Agent探测成功: ' + endpoint);
      notify('Agent已连接: 端口 ' + ports[i]);
      return endpoint;
    }
  }

  log('所有Agent端口探测失败');
  return null;
}

/* ==================== 统一AI调用 ==================== */
function buildPrompt(question, options) {
  var lines = [];
  if (question.type) {
    var typeMap = { single: '单选', multiple: '多选', judge: '判断', fill: '填空', essay: '简答' };
    lines.push('【题型】' + (typeMap[question.type] || question.type));
  }
  lines.push('【题目】' + question.stem);
  if (options && options.length > 0) {
    lines.push('【选项】');
    options.forEach(function(o) { lines.push(o.key + '. ' + o.text); });
  }
  lines.push('');
  lines.push('请只回复正确答案的字母（如 A 或 AB 或 ABC），不要回复其他内容。');
  return lines.join('\n');
}

async function callOpenAICompatible(baseUrl, model, prompt, apiKey) {
  var url = baseUrl.replace(/\/+$/, '');
  if (!/\/chat\/completions$/.test(url)) {
    if (!/\/v1$/.test(url)) url += '/v1';
    url += '/chat/completions';
  }

  var headers = { 'Content-Type': 'application/json' };
  if (apiKey) headers['Authorization'] = 'Bearer ' + apiKey;

  try {
    var data = await proxyFetch(url, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        model: model,
        messages: [{ role: 'user', content: prompt }],
        stream: false,
        temperature: 0.2,
        max_tokens: 2048
      })
    });

    var content = '';
    if (data.choices && data.choices[0]) {
      content = data.choices[0].message && data.choices[0].message.content || '';
    }
    return content.trim();
  } catch (e) {
    log('请求异常:', e.message);
    return null;
  }
}

async function askAI(question, options) {
  var cfg = await getConfig();
  var mode = getMode(cfg);
  var prompt = buildPrompt(question, options);
  var raw = null;

  try {
    if (mode === 'local') {
      raw = await askLocalAI(cfg, prompt);
    } else if (mode === 'agent') {
      raw = await askAgent(cfg, prompt);
    } else if (mode === 'cloud') {
      raw = await askCloudAI(cfg, prompt);
    }
  } catch (e) {
    log('AI 请求异常:', e.message);
    return null;
  }

  if (!raw) return null;
  return parseAnswer(raw);
}

async function askLocalAI(cfg, prompt) {
  var baseUrl = ((cfg.local || {}).baseUrl || 'http://localhost:11434').replace(/\/+$/, '');
  if (!/\/v1$/.test(baseUrl)) baseUrl += '/v1';
  var model = await ensureModel(cfg);
  if (!model) return null;

  log('调用本地AI [' + model + '] ...');
  return await callOpenAICompatible(baseUrl, model, prompt, (cfg.local || {}).apiKey || 'ollama');
}

async function askAgent(cfg, prompt) {
  var endpoint = await detectAgentEndpoint();
  if (!endpoint) {
    log('Agent不可用，回退到本地AI');
    return await askLocalAI(cfg, prompt);
  }

  var model = ((cfg.wsl || {}).agentName) || 'study-agent';
  log('调用Agent [' + endpoint + '] ...');
  return await callOpenAICompatible(endpoint, model, prompt, (cfg.wsl || {}).apiKey || '');
}

async function askCloudAI(cfg, prompt) {
  var cloud = cfg.cloud || {};
  if (!cloud.apiKey) {
    log('云端AI未配置API Key');
    notify('请先配置云端AI的API Key');
    return null;
  }

  var baseUrl = (cloud.baseUrl || 'https://api.openai.com/v1').replace(/\/+$/, '');
  var model = cloud.model || 'gpt-4o-mini';
  log('调用云端AI [' + model + '] ...');
  return await callOpenAICompatible(baseUrl, model, prompt, cloud.apiKey);
}

/* ==================== 答案解析 ==================== */
function parseAnswer(answer) {
  var clean = answer.replace(/```[\s\S]*?```/g, '').replace(/<[^>]+>/g, '').trim();

  var m1 = clean.match(/答案[是为：:\s]*([A-G][\s,，、]*[A-G]?[\s,，、]*[A-G]?[\s,，、]*[A-G]?)/i);
  if (m1) return m1[1].replace(/[\s,，、]/g, '').toUpperCase();

  var m2 = clean.match(/^[\s]*([A-G]{1,6})[\s]*$/m);
  if (m2) return m2[1].toUpperCase();

  var m3 = clean.match(/\b([A-G])\b/g);
  if (m3 && m3.length <= 6) {
    var unique = [];
    m3.forEach(function(c) { if (unique.indexOf(c) === -1) unique.push(c); });
    if (unique.length <= 6) return unique.join('');
  }

  log('无法解析答案:', answer.slice(0, 100));
  return null;
}

/* ==================== 题目提取 ==================== */
function extractQuestionFromNode(qDiv) {
  try {
    var titleEl = qDiv.querySelector(SEL.title);
    if (!titleEl) return null;

    var stem = titleEl.innerText.trim();
    stem = stem.replace(/^第?\s*\d+[\.、\s]+题[\.、:：\s]*/, '');
    stem = stem.replace(/^判断题\s*/, '');
    stem = stem.replace(/^单选题\s*/, '');
    stem = stem.replace(/^多选题\s*/, '');
    stem = stem.replace(/^填空题\s*/, '');
    if (!stem || stem.length < 2) return null;

    var type = 'unknown';
    var fullText = qDiv.innerText || '';
    if (/判断|对错/.test(fullText)) type = 'judge';
    else if (/单选/.test(fullText)) type = 'single';
    else if (/多选/.test(fullText)) type = 'multiple';
    else if (/填空/.test(fullText)) type = 'fill';
    else if (/简答|问答/.test(fullText)) type = 'essay';

    var options = [];
    var optionEls = qDiv.querySelectorAll(SEL.option);
    optionEls.forEach(function(el, idx) {
      var key = String.fromCharCode(65 + idx);
      var text = el.innerText.replace(/^[A-G][\.、\s]*/, '').trim();
      if (text) options.push({ key: key, text: text });
    });

    return { stem: stem, type: type, options: options };
  } catch (e) {
    return null;
  }
}

/* ==================== 题目检测与答题 ==================== */
async function solveQuiz() {
  var solved = 0;

  /* 策略1: 在当前页面的弹窗中查找题目 */
  var dialogs = document.querySelectorAll(SEL.dialog);
  for (var d = 0; d < dialogs.length; d++) {
    solved += await processContainer(dialogs[d]);
  }

  /* 策略2: 在当前页面直接查找题目（非弹窗） */
  var directQuestions = document.querySelectorAll(SEL.question);
  for (var q = 0; q < directQuestions.length; q++) {
    var qDiv = directQuestions[q];
    if (qDiv.getAttribute('data-cx-solved')) continue;
    if (isInsideDialog(qDiv)) continue;

    var qData = extractQuestionFromNode(qDiv);
    if (!qData || qData.options.length === 0) continue;

    log('检测到页面内题目: ' + qData.stem.slice(0, 40) + '...');
    var result = await solveOne(qDiv, qData);
    if (result) solved++;
  }

  /* 策略3: 穿透iframe查找题目 */
  var iframes = document.querySelectorAll('iframe');
  for (var f = 0; f < iframes.length; f++) {
    try {
      var iframeDoc = iframes[f].contentDocument;
      if (!iframeDoc) continue;

      var iframeDialogs = iframeDoc.querySelectorAll(SEL.dialog);
      for (var id = 0; id < iframeDialogs.length; id++) {
        solved += await processContainer(iframeDoc, iframeDialogs[id]);
      }

      var iframeQuestions = iframeDoc.querySelectorAll(SEL.question);
      for (var iq = 0; iq < iframeQuestions.length; iq++) {
        var iqDiv = iframeQuestions[iq];
        if (iqDiv.getAttribute('data-cx-solved')) continue;

        var iqData = extractQuestionFromNode(iqDiv);
        if (!iqData || iqData.options.length === 0) continue;

        log('检测到iframe内题目: ' + iqData.stem.slice(0, 40) + '...');
        var iResult = await solveOne(iqDiv, iqData);
        if (iResult) solved++;
      }
    } catch (e) {}
  }

  if (solved > 0) {
    log('本轮成功解答 ' + solved + ' 道题目');
  }
}

function isInsideDialog(node) {
  var parent = node.parentElement;
  while (parent) {
    if (parent.matches && parent.matches(SEL.dialog)) return true;
    parent = parent.parentElement;
  }
  return false;
}

async function processContainer(docOrContainer, container) {
  if (!container) { container = docOrContainer; }
  var doc = docOrContainer.ownerDocument || docOrContainer;
  var solved = 0;
  var questions = container.querySelectorAll(SEL.question);
  for (var i = 0; i < questions.length; i++) {
    var qDiv = questions[i];
    if (qDiv.getAttribute('data-cx-solved')) continue;

    var qData = extractQuestionFromNode(qDiv);
    if (!qData || qData.options.length === 0) continue;

    var result = await solveOne(qDiv, qData);
    if (result) solved++;
  }
  return solved;
}

async function solveOne(qDiv, qData) {
  try {
    log('正在解答: ' + qData.stem.slice(0, 50) + '...');

    var answer = await Promise.race([
      askAI(qData.stem, qData.options),
      new Promise(function(resolve) {
        setTimeout(function() {
          resolve('__TIMEOUT__');
        }, AI_CONFIG.refreshTimeout);
      })
    ]);

    if (answer === '__TIMEOUT__') {
      log('AI 10秒无响应，刷新页面...');
      notify('AI 超时，正在刷新页面...');
      if (!_refreshed) {
        _refreshed = true;
        setTimeout(function() { location.reload(); }, 500);
      }
      return false;
    }

    if (!answer) {
      log('未获取到答案');
      return false;
    }

    log('答案: ' + answer);

    var clicked = clickOptions(qDiv, answer, qData.type);
    if (clicked) {
      qDiv.setAttribute('data-cx-solved', 'true');
      qDiv.style.background = '#e8f5e9';
      qDiv.style.border = '2px solid #4CAF50';
      return true;
    }
    return false;
  } catch (e) {
    log('答题异常:', e.message);
    return false;
  }
}

/* ==================== 选项点击 ==================== */
function clickOptions(qDiv, answer, type) {
  answer = answer.toUpperCase();
  var clicked = false;
  var optionContainers = qDiv.querySelectorAll(SEL.option);

  optionContainers.forEach(function(el, idx) {
    var key = String.fromCharCode(65 + idx);
    if (answer.indexOf(key) !== -1) {
      el.click();
      clicked = true;
    }
  });

  if (!clicked && optionContainers.length > 0) {
    var input = qDiv.querySelector('input, textarea, [contenteditable="true"]');
    if (input) {
      input.value = answer;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      clicked = true;
    }
  }

  return clicked;
}

/* ==================== 手动刷新 ==================== */
function refreshPage() {
  log('手动刷新页面');
  notify('正在刷新页面...');
  _refreshed = true;
  setTimeout(function() { location.reload(); }, 300);
}

/* ==================== 启动 ==================== */
function startSolver() {
  log('答题模块 v3.1 已启动');
  log('超时: ' + (AI_CONFIG.timeout / 1000) + '秒');
  log('AI无响应刷新: ' + (AI_CONFIG.refreshTimeout / 1000) + '秒');
  log('Agent端口: ' + AI_CONFIG.agentPorts.join(', '));
  log('选择器: 弹窗=' + SEL.dialog.slice(0, 50) + '...');
  log('选择器: 题目=' + SEL.question);

  getConfig().then(function(cfg) {
    log('当前模式: ' + getMode(cfg));
    if (getMode(cfg) === 'local') {
      ensureModel(cfg);
    }
  });

  setInterval(function() {
    try {
      solveQuiz();
    } catch (e) {
      log('答题检测异常:', e.message);
    }
  }, 3000);
}

global.SAAISolver = {
  config: AI_CONFIG,
  askAI: askAI,
  solveQuiz: solveQuiz,
  start: startSolver,
  refreshPage: refreshPage,
  detectModels: detectOllamaModels,
  detectAgent: detectAgentEndpoint
};

})(typeof self !== 'undefined' ? self : globalThis);
