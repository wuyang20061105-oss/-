// doc.js - 文档滚动控制 (照搬 xuexitong_addon)
(function() {
  if (window.__cx_doc_loaded__) return;
  window.__cx_doc_loaded__ = true;
  console.log("[Doc] 文档模块已挂载 - " + window.location.href);

  var DocWorker = {
      isFinished: false,

      read: function() {
          if (this.isFinished) return;
          console.log("[Doc] 开始翻阅文档...");

          var sameScrollCount = 0;
          var lastScrollTop = -1;
          var self = this;

          var scrollInterval = setInterval(function() {
              if (self.isFinished) {
                  clearInterval(scrollInterval);
                  return;
              }

              var nextBtn = document.querySelector('.nextBtn, #nextBtn, .mke-next-btn, .next, .turnpage_Btn');
              if (nextBtn && window.getComputedStyle(nextBtn).display !== 'none' && !nextBtn.className.includes('disabled')) {
                  nextBtn.click();
                  sameScrollCount = 0;
                  return;
              }

              var scrolled = false;

              if (document.documentElement.scrollHeight > document.documentElement.clientHeight) {
                  window.scrollTo(0, 999999);
                  scrolled = true;
              }

              document.querySelectorAll('div').forEach(function(el) {
                  if (el.scrollHeight > el.clientHeight + 10) {
                      el.scrollTop = el.scrollHeight;
                      scrolled = true;
                  }
              });

              var scrollElement = document.scrollingElement || document.documentElement || document.body;
              var currentScrollTop = scrollElement.scrollTop;
              var maxScrollTop = scrollElement.scrollHeight - scrollElement.clientHeight;

              if (scrolled || maxScrollTop > 10) {
                  if (currentScrollTop >= maxScrollTop - 20) {
                      sameScrollCount += 3;
                  } else if (currentScrollTop === lastScrollTop) {
                      sameScrollCount += 2;
                  } else {
                      sameScrollCount = 0;
                  }
                  lastScrollTop = currentScrollTop;
              } else {
                  sameScrollCount = 0;
              }

              if (sameScrollCount >= 4) {
                  clearInterval(scrollInterval);
                  self.isFinished = true;
                  console.log("[Doc] 文档已滚动到底部，准备汇报...");

                  var p = window;
                  while (p !== window.top) {
                      try {
                          p = p.parent;
                          p.postMessage({ action: "TASK_FINISHED", type: "doc" }, '*');
                      } catch (e) {
                          break;
                      }
                  }
                  window.top.postMessage({ action: "TASK_FINISHED", type: "doc" }, '*');
              }
          }, 500);
      }
  };

  window.addEventListener('message', function(event) {
      if (event.data && event.data.action === 'START_DOC') {
          document.querySelectorAll('iframe').forEach(function(iframe) {
              try {
                  iframe.contentWindow.postMessage(event.data, '*');
              } catch (e) {}
          });
          DocWorker.read();
      }
  });
})();
