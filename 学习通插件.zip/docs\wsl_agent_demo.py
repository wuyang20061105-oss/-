﻿"""
WSL Agent Demo - 最小可运行的 FastAPI 服务

接口：
  GET  /health           -> {"ok": true}
  POST /answer           -> {answer, steps, sources, traceId}
  POST /stream           -> SSE (data: {"delta": "..."})

替换 call_llm() 即可对接真实模型。
"""
import asyncio
import json
import uuid
from typing import AsyncGenerator, List, Optional

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

app = FastAPI(title="Study Agent")


# ============ 数据模型 ============
class Question(BaseModel):
    stem: str
    type: Optional[str] = None
    options: Optional[List[dict]] = None
    engine: Optional[str] = None


class HistoryItem(BaseModel):
    role: str
    content: str


class AnswerReq(BaseModel):
    agent: str = "study-agent"
    question: Question
    history: List[HistoryItem] = []


# ============ Mock LLM ============
# 替换为真实调用（Ollama / vLLM / OpenAI / LangChain）
async def call_llm_sync(messages: List[dict]) -> str:
    """同步调用：返回完整文本。替换为真实 LLM 调用"""
    user_msg = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    return (
        f"【演示回复】\n\n"
        f"你问的是：{user_msg[:200]}\n\n"
        f"实际部署时，请将本函数替换为真实 LLM 调用：\n"
        f" - Ollama:  POST http://localhost:11434/api/chat\n"
        f" - vLLM:    POST http://localhost:8000/v1/chat/completions\n"
        f" - OpenAI:  POST https://api.openai.com/v1/chat/completions"
    )


async def call_llm_stream(messages: List[dict]) -> AsyncGenerator[str, None]:
    """流式调用：逐字返回。替换为真实 LLM 流式调用 (SSE)"""
    user_msg = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    text = (
        "【演示流式回复】\n\n"
        f"你问的是：{user_msg[:200]}\n\n"
        "实际部署时，将本函数替换为真实 LLM 流式调用 (SSE)。"
    )
    for ch in text:
        yield ch
        await asyncio.sleep(0.01)


# 向后兼容：旧调用方
async def call_llm(messages: List[dict], stream: bool = False):
    """保留旧接口。stream=True 返回生成器。"""
    if stream:
        return call_llm_stream(messages)
    return await call_llm_sync(messages)


# ============ Prompt 构造 ============
def build_prompt(question: Question, history: List[HistoryItem]) -> List[dict]:
    lines = [f"【题目】\n{question.stem}"]
    if question.type:
        type_zh = {
            "single": "单选", "multiple": "多选", "judge": "判断",
            "fill": "填空", "essay": "简答"
        }.get(question.type, question.type)
        lines.append(f"【题型】{type_zh}")
    if question.options:
        lines.append("【选项】")
        for opt in question.options:
            lines.append(f"{opt.get('key', '?')}. {opt.get('text', '')}")
    lines.append("\n请直接给出答案与详细解析。")

    msgs = [
        {"role": "system", "content": "你是一个严谨的大学网课助教。"},
    ]
    for h in history[-6:]:
        msgs.append({"role": h.role, "content": h.content})
    msgs.append({"role": "user", "content": "\n".join(lines)})
    return msgs


# ============ 路由 ============
@app.get("/health")
async def health():
    return {"ok": True, "agent": "study-agent"}


@app.post("/answer")
async def answer(req: AnswerReq):
    msgs = build_prompt(req.question, req.history)
    text = await call_llm_sync(msgs)
    return {
        "answer": text,
        "steps": [],
        "sources": ["mock-demo"],
        "traceId": str(uuid.uuid4()),
    }


@app.post("/stream")
async def stream(req: AnswerReq):
    """SSE 流式输出"""
    msgs = build_prompt(req.question, req.history)
    source = call_llm_stream(msgs)

    async def gen() -> AsyncGenerator[str, None]:
        try:
            async for chunk in source:
                yield f"data: {json.dumps({'delta': chunk}, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8787)
