﻿# 图标目录

需要放置 4 张 PNG，尺寸分别：

-`icon16.png` (16×16)
-`icon32.png` (32×32)
-`icon48.png` (48×48)
-`icon128.png` (128×128)

## 快速生成（任选一种）

### 方式 A：emoji 转 png
1. 打开 <https://favicon.io/emoji-favicons/>，搜索 智能助手
2. 下载 zip，解压出`favicon-16x16.png` /`favicon-32x32.png` 等
3. 改名为`icon16.png` /`icon32.png` /`icon48.png` /`icon128.png` 放入本目录

### 方式 B：Python 一键生成
```python
from PIL import Image, ImageDraw, ImageFont
for s in [16, 32, 48, 128]:
img = Image.new('RGBA', (s, s), (99, 102, 241, 255))
d = ImageDraw.Draw(img)
f = ImageFont.truetype("arial.ttf", int(s*0.6))
d.text((s*0.2, s*0.05), "智能助手", fill='white', font=f)
img.save(f"icon{s}.png")
```

### 方式 C：临时跳过
把`manifest.json` 中所有`default_icon` /`action.default_icon` 字段删除，Chrome 会用默认占位图。
