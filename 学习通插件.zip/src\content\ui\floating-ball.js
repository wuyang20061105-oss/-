/**
 * 悬浮球 UI - Shadow DOM 隔离
 *
 * 功能：
 *  - 右下角悬浮球（白底蓝图标，可拖动）
 *  - 点击展开快捷面板
 *  - 拖动后自动贴边
 *  - 自动学习运行时显示脉冲光晕
 *  - 收到 background 推送时显示红点
 */
(function (global) {
'use strict';

const log = global.SALogger;
const HOST_ID = 'sa-floating-ball-host';
const STYLE_URL = chrome.runtime.getURL('src/content/ui/shadow-host.css');
const STORAGE_POS = 'sa_ball_pos_v1';

function createHost() {
  let host = document.getElementById(HOST_ID);
  if (host) return host;
  host = document.createElement('div');
  host.id = HOST_ID;
  host.setAttribute('data-sa-shadow', '');
  host.style.cssText = 'all: initial; position: fixed; right: 20px; bottom: 80px; z-index: 2147483647; pointer-events: none;';
  document.documentElement.appendChild(host);
  return host;
}

function createShadow(host) {
  const sr = host.attachShadow({ mode: 'open' });
  sr.innerHTML = `
    <link rel="stylesheet" href="${STYLE_URL}">
    <div class="sa-ball" id="ball" title="网课助手">
      <span class="sa-ball-icon">AI</span>
      <span class="sa-ball-dot" id="dot" hidden></span>
    </div>
    <div class="sa-panel" id="panel" hidden>
      <div class="sa-panel-header">网课助手</div>
      <button data-action="capture">立即抓题</button>
      <button data-action="open-side">打开侧边栏</button>
      <button data-action="refresh-page">刷新页面</button>
      <button data-action="upload-pdf">上传 PDF</button>
      <input type="file" id="pdf-input" accept="application/pdf" hidden />
      <button data-action="settings">设置</button>
      <div class="sa-panel-tip">Alt+Q 快速抓题 · Alt+S 切换侧边栏</div>
    </div>
  `;
  return sr;
}

function bind(sr) {
  const ball = sr.getElementById('ball');
  const panel = sr.getElementById('panel');
  const dot = sr.getElementById('dot');
  const fileInput = sr.getElementById('pdf-input');
  const host = ball.getRootNode().host;

  // 恢复位置
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_POS) || 'null');
    if (saved && typeof saved.right === 'number' && typeof saved.bottom === 'number') {
      host.style.right = saved.right + 'px';
      host.style.bottom = saved.bottom + 'px';
    }
  } catch (e) {}

  // 拖动
  let dragState = null;
  ball.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    const r = host.getBoundingClientRect();
    dragState = {
      startX: e.clientX,
      startY: e.clientY,
      origRight: window.innerWidth - r.right,
      origBottom: window.innerHeight - r.bottom,
      moved: false
    };
    ball.setPointerCapture(e.pointerId);
    ball.classList.add('dragging');
  });

  ball.addEventListener('pointermove', e => {
    if (!dragState) return;
    const dx = e.clientX - dragState.startX;
    const dy = e.clientY - dragState.startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) dragState.moved = true;
    host.style.right = Math.max(8, dragState.origRight - dx) + 'px';
    host.style.bottom = Math.max(8, dragState.origBottom - dy) + 'px';
  });

  ball.addEventListener('pointerup', e => {
    if (!dragState) return;
    ball.releasePointerCapture(e.pointerId);
    ball.classList.remove('dragging');
    if (dragState.moved) {
      const r = host.getBoundingClientRect();
      host.style.right = (window.innerWidth - r.right < window.innerWidth / 2)
        ? Math.max(8, window.innerWidth - r.right) + 'px'
        : '20px';
      persistPos(host);
    }
    dragState = null;
  });

  ball.addEventListener('click', () => {
    if (dragState?.moved) return;
    const shown = !panel.hidden;
    panel.hidden = shown;
    ball.classList.toggle('sa-ball--active', !shown);
  });

  sr.addEventListener('click', async e => {
    const action = e.target?.dataset?.action;
    if (!action) return;
    panel.hidden = true;
    ball.classList.remove('sa-ball--active');

    try {
      switch (action) {
        case 'capture':
          await global.SAMessage.send('sidepanel:captureNow');
          break;
        case 'open-side':
          await chrome.runtime.sendMessage({ type: 'sidepanel:open' });
          break;
        case 'upload-pdf':
          fileInput.click();
          break;
        case 'settings':
          chrome.runtime.openOptionsPage();
          break;
        case 'refresh-page':
          if (global.SAAISolver) global.SAAISolver.refreshPage();
          else location.reload();
          break;
      }
    } catch (err) {
      log.error('Ball', err);
    }
  });

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    try {
      const text = await self.SAPdfExtractor.extractFromFile(file);
      const result = await global.SAMessage.send('ai:answer', {
        question: {
          stem: '请基于以下 PDF（' + file.name + '）内容回答用户问题，必要时输出摘要。\n\n' + text.fullText.slice(0, 12000),
          type: 'pdf'
        }
      });
      await chrome.runtime.sendMessage({ type: 'sidepanel:open' });
      await global.SAMessage.send('sidepanel:pushResult', { kind: 'pdf', result });
    } catch (e) {
      log.error('Ball', 'PDF 处理失败:', e);
    }
    fileInput.value = '';
  });

  chrome.runtime.onMessage.addListener(msg => {
    if (msg?.type === 'ball:notify') {
      dot.hidden = false;
      dot.title = msg.payload?.text || '新消息';
      setTimeout(() => { dot.hidden = true; }, 5000);
    }
    if (msg?.type === 'automation:state') {
      const running = msg.payload?.running;
      ball.classList.toggle('running', !!running);
      // 更新标题显示状态
      ball.title = running ? '自动学习运行中' : '网课助手';
    }
  });
}

function persistPos(host) {
  try {
    const r = host.getBoundingClientRect();
    localStorage.setItem(STORAGE_POS, JSON.stringify({
      right: window.innerWidth - r.right,
      bottom: window.innerHeight - r.bottom
    }));
  } catch (e) {}
}

global.SAFloatingBall = {
  mount() {
    if (document.getElementById(HOST_ID)) return;
    const host = createHost();
    const sr = createShadow(host);
    bind(sr);
    log.info('Ball', 'mounted');
  },
  notify(text) {
    const host = document.getElementById(HOST_ID);
    const sr = host?.shadowRoot;
    const dot = sr?.getElementById('dot');
    if (dot) { dot.hidden = false; dot.title = text; }
  }
};
})(typeof self !== 'undefined' ? self : globalThis);
