/**
* 统一日志工具
* 在生产环境可统一关闭 debug 级别
*/
(function (global) {
'use strict';

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const CURRENT_LEVEL = LEVELS[global.__SA_LOG_LEVEL__] ?? LEVELS.debug;

function format(tag, args) {
return [`%c[SA:${tag}]`, 'color:#3b82f6;font-weight:bold', ...args];
}

const logger = {
debug(tag, ...args) {
if (CURRENT_LEVEL <= LEVELS.debug) console.debug(...format(tag, args));
},
info(tag, ...args) {
if (CURRENT_LEVEL <= LEVELS.info) console.info(...format(tag, args));
},
warn(tag, ...args) {
if (CURRENT_LEVEL <= LEVELS.warn) console.warn(...format(tag, args));
},
error(tag, ...args) {
if (CURRENT_LEVEL <= LEVELS.error) console.error(...format(tag, args));
}
};

global.SALogger = logger;
})(typeof self !== 'undefined' ? self : globalThis);
