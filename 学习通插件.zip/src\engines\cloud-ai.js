/**
 * 云端 AI 引擎 (v2.0)
 *
 * 统一使用 OpenAI Chat Completions 协议
 * 支持: OpenAI / DeepSeek / 通义千问 / 智谱AI / 任何兼容API
 *
 * 超时: 10分钟
 */
import { BaseEngine } from './base.js';

export class CloudAIEngine extends BaseEngine {
  constructor(cfg) {
    super(cfg);
    this.baseUrl = (cfg.baseUrl || 'https://api.openai.com/v1').replace(/\/+$/, '');
    this.apiKey = cfg.apiKey || '';
    this.model = cfg.model || 'gpt-4o-mini';
    this.temperature = Number(cfg.temperature ?? 0.2);
    this.maxTokens = Number(cfg.maxTokens ?? 2048);
    this.systemPrompt = cfg.systemPrompt || '你是一个严谨的大学网课助教。';
    this.timeoutMs = 600000;
  }

  _headers() {
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.apiKey}`
    };
  }

  _messages(question) {
    const msgs = [{ role: 'system', content: this.systemPrompt }];
    msgs.push({ role: 'user', content: this.buildPrompt(question) });
    return msgs;
  }

  async answer(question, history) {
    if (!this.apiKey) throw new Error('云端AI：API密钥未配置');

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify({
          model: this.model,
          messages: this._messages(question),
          temperature: this.temperature,
          max_tokens: this.maxTokens,
          stream: false
        }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        if (res.status === 401) throw new Error('认证失败，请检查API密钥');
        if (res.status === 429) throw new Error('请求频率超限，请稍后重试');
        if (res.status === 402) throw new Error('额度不足');
        throw new Error(`云端AI ${res.status}: ${text.slice(0, 300)}`);
      }
      const data = await res.json();
      const answer = data?.choices?.[0]?.message?.content || '';
      return { answer, raw: data };
    } catch (e) {
      clearTimeout(timer);
      throw e;
    }
  }

  async *streamAnswer(question, history, abort) {
    if (!this.apiKey) throw new Error('云端AI：API密钥未配置');

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    if (typeof abort === 'function') {
      const check = setInterval(() => abort() && ctrl.abort(), 500);
      ctrl.signal.addEventListener('abort', () => clearInterval(check));
    }
    try {
      const res = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { ...this._headers(), Accept: 'text/event-stream' },
        body: JSON.stringify({
          model: this.model,
          messages: this._messages(question),
          temperature: this.temperature,
          max_tokens: this.maxTokens,
          stream: true
        }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`cloud stream ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      while (true) {
        if (abort?.()) return;
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          const s = line.trim();
          if (!s.startsWith('data:')) continue;
          const payload = s.slice(5).trim();
          if (payload === '[DONE]') return;
          try {
            const json = JSON.parse(payload);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) yield delta;
          } catch {}
        }
      }
    } finally {
      clearTimeout(timer);
    }
  }
}
