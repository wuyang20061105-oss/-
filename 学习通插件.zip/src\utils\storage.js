/**
* 存储封装
* - 优先使用 chrome.storage.local（容量大，跨域同步可关）
* - 对外暴露 Promise 接口，避免回调地狱
*/
(function (global) {
'use strict';

const KEY = 'sa_config_v1';

const DEFAULTS = {
mode: 'local',

thirdparty: {
provider: 'soutijiang',
token: '',
cookie: '',
endpoint: 'https://api.universitysouti.com/v1/question/search'
},

local: {
baseUrl: 'http://localhost:11434/v1',
apiKey: 'ollama',
    model: '',
temperature: 0.2,
maxTokens: 2048,
systemPrompt: '你是一个严谨的大学网课助教，请给出准确答案与详细解析步骤。'
},

  cloud: {
    baseUrl: 'https://api.openai.com/v1',
    apiKey: '',
    model: 'gpt-4o-mini',
    temperature: 0.2,
    maxTokens: 2048,
    systemPrompt: '你是一个严谨的大学网课助教，请给出准确答案与详细解析步骤。'
  },

wsl: {
baseUrl: 'http://localhost:8787',
apiKey: '',
agentName: 'study-agent',
timeoutMs: 60000
},

ui: {
autoOpen: true,
showFloatingBall: true,
ballPosition: 'right-middle'
},

  automation: {
    autoSkipVideo: false,
    muteVideo: true,
    playRate: 1,
    autoAnswer: false,
    autoSubmit: false
  }
};

function deepMerge(target, source) {
  const result = { ...target };
  for (const key of Object.keys(source)) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key]) && target[key] && typeof target[key] === 'object' && !Array.isArray(target[key])) {
      result[key] = deepMerge(target[key], source[key]);
    } else {
      result[key] = source[key];
    }
  }
  return result;
}

async function getConfig() {
return new Promise(resolve => {
chrome.storage.local.get([KEY],res => {
const stored =res[KEY];
if (!stored)return resolve(structuredClone(DEFAULTS));
resolve(deepMerge(structuredClone(DEFAULTS), stored));
});
});
}

async function setConfig(patch) {
const current = await getConfig();
const next = deepMerge(current, patch);
return new Promise(resolve => {
chrome.storage.local.set({ [KEY]:next }, () =>resolve(next));
});
}

async function resetConfig() {
return new Promise(resolve => {
chrome.storage.local.remove(KEY, () =>resolve(structuredClone(DEFAULTS)));
});
}

global.SAStorage = { getConfig, setConfig,resetConfig, DEFAULTS };
})(typeof self !== 'undefined' ? self : globalThis);
