/**
* 模式A：第三方题库引擎
*
* 适配大学搜题酱 / 作业帮 公开/半公开 API
* 警告 注意：第三方题库需自行解决账号/付费问题，本文件仅给出通用对接框架
*/
import { BaseEngine } from './base.js';

export class ThirdpartyEngine extends BaseEngine {
constructor(cfg) {
super(cfg);
this.provider = cfg.provider || 'soutijiang';
this.token = cfg.token || '';
this.cookie = cfg.cookie || '';
this.endpoint = cfg.endpoint || '';
}

async answer(question) {
const payload = {
q: question.stem,
type: question.type,
options: question.options
};

// 不同 provider 走不同分支
let url, headers, body;
if (this.provider === 'soutijiang') {
url = 'https://api.universitysouti.com/v1/question/search';
headers = {
'Content-Type': 'application/json',
'Authorization':`Bearer ${this.token}`,
'User-Agent': 'Mozilla/5.0 StudyAssistant/1.0'
};
body = JSON.stringify({ question: payload.q, options: payload.options });
} else if (this.provider === 'zuoyebang') {
// 作业帮：典型走 H5 接口，需 cookie 风控
url = 'https://gateway.kangaroo-ai.com/api/question/match';
headers = {
'Content-Type': 'application/json',
'Cookie': this.cookie,
'x-token': this.token
};
body = JSON.stringify({ text: payload.q, type: 'QUESTION' });
} else {
throw new Error(`unknown provider: ${this.provider}`);
}

const res = await fetch(url, { method: 'POST', headers, body });
if (!res.ok) throw new Error(`thirdparty ${res.status}: ${await res.text()}`);
const data = await res.json();

return this.normalize(data);
}

/**
* 不同 provider 返回结构差异很大，统一归一化为：
* { answer: string, steps?: string[], sources?: string[] }
*/
normalize(raw) {
if (this.provider === 'soutijiang') {
return {
answer: raw?.data?.answer ?? raw?.answer ?? '未找到答案',
steps:raw?.data?.analysis ? [raw.data.analysis] : [],
sources:raw?.data?.from ? [raw.data.from] : []
};
}
if (this.provider === 'zuoyebang') {
return {
answer: raw?.result?.answer ?? raw?.answer ?? '未找到答案',
steps:raw?.result?.analysis ? [raw.result.analysis] : [],
sources:raw?.result?.references || []
};
}
return { answer: JSON.stringify(raw) };
}

/** 第三方通常不提供流式，但保留接口以符合基类 */
async *streamAnswer(q, h, abort) {
const r = await this.answer(q, h);
const text =r.steps?.length ?`${r.answer}\n\n${r.steps.join('\n')}` :r.answer;
for (const line of text.split(/(?<=[。！？\n])/)) {
if (abort?.())return;
yield line;
await sleep(20);
}
}
}

function sleep(ms) {return new Promise(r => setTimeout(r, ms)); }
