/**
 * Content Script 入口
 * - 防重复注入
 * - 注入悬浮球（仅顶层 frame）
 * - 接收消息并转发给 automation
 */
(function () {
  'use strict';

  if (self.__SA_LOADED__) return;
  self.__SA_LOADED__ = true;

  var log = self.SALogger;

  var IS_TOP = (function() { try { return window.top === window.self; } catch (e) { return true; } })();

  log.info('Content', 'script loaded, IS_TOP=' + IS_TOP + ', host=' + location.host);

  // ==================== 消息监听 ====================
  window.addEventListener('message', function(event) {
    if (!event.data) return;
    var data = event.data;

    // 参考插件格式的消息 - 直接转发，不需要额外处理
    // video.js 和 doc.js 会自己处理 START_VIDEO / START_DOC

    // 自己的格式
    if (data.source !== 'sa-extension') return;
    var payload = data.payload;

    if (data.type === 'automation:toggle' && self.SAAutomation) {
      if (payload && payload.enabled) {
        self.SAAutomation.start();
      } else {
        self.SAAutomation.stop();
      }
    }
  });

  // ==================== 注入悬浮球 ====================
  if (IS_TOP && self.SAFloatingBall) {
    self.SAFloatingBall.mount();
  }

  // ==================== 启动自动化模块 ====================
  if (self.SAAutomation) {
    self.SAAutomation.bootstrap().catch(function(err) {
      log.warn('Content', 'automation bootstrap failed:', err);
    });
  }

  // ==================== 消息路由（供 Side Panel 使用） ====================
  if (self.SAMessage) {
    self.SAMessage.listen({
      'page:info': async function() {
        if (!IS_TOP) return null;
        var isLogin = /登录|login|signin/i.test(location.pathname);
        var videos = document.querySelectorAll('video, audio').length;
        var iframes = document.querySelectorAll('iframe').length;
        return {
          host: location.host,
          pathname: location.pathname,
          title: document.title,
          isLogin: isLogin,
          videoCount: videos,
          iframeCount: iframes,
          hints: isLogin ? ['当前是登录页，请先登录'] : ['检测到 ' + videos + ' 个视频, ' + iframes + ' 个 iframe']
        };
      },
      'automation:getState': async function() {
        return self.SAAutomation ? self.SAAutomation.getPublicState() : null;
      },
      'automation:toggle': async function(payload) {
        if (!self.SAAutomation) return false;
        if (payload && payload.enabled) {
          self.SAAutomation.start();
        } else {
          self.SAAutomation.stop();
        }
        return true;
      },
      'ai:answer': async function(payload) {
        if (!payload || !payload.question) return { answer: null };
        var q = payload.question;
        var options = q.options || [];
        var answer = await self.SAAISolver.askAI(q.stem, options);
        return { answer: answer };
      },
      'content:refreshPage': async function() {
        if (self.SAAISolver) self.SAAISolver.refreshPage();
        else location.reload();
        return true;
      },
      'content:extractQuestions': async function() {
        var questions = [];
        var qDivs = document.querySelectorAll('.TiMu, .question-item, .topic, .singleQuesId');
        qDivs.forEach(function(qDiv, idx) {
          try {
            var titleEl = qDiv.querySelector('h3.mark_name, .Zy_TItle, .topic-title');
            if (!titleEl) return;
            var stem = titleEl.innerText.trim();
            if (!stem || stem.length < 3) return;

            var options = [];
            var optionEls = qDiv.querySelectorAll('.answerBg, li, .option');
            optionEls.forEach(function(el, i) {
              var key = String.fromCharCode(65 + i);
              var text = el.innerText.replace(/^[A-G][\.、\s]*/, '').trim();
              options.push({ key: key, text: text });
            });

            questions.push({
              id: 'q_' + idx,
              stem: stem,
              options: options,
              answer: null
            });
          } catch (e) {}
        });
        return { questions: questions };
      }
    });
  }

  log.info('Content', 'script ready on', location.host);
})();
