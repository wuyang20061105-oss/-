/**
 * 侧边栏主控
 * - 模式切换 (本地 AI / Agent / 云端 AI)
 * - 题目捕获 / 解答
 * - 自动学习控制
 */
(function () {
'use strict';

const log = self.SALogger;
const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

const state = {
  mode: 'local',
  questions: [],
  isCapturing: false,
  autoFrames: new Map(),
  autoState: { running: false, enabled: false, stats: {}, frameCount: 0 },
  _localToggle: null,
  aiStatus: { connected: false, checking: false, models: [], modelHint: '' },
  cloudConfig: { baseUrl: '', apiKey: '', model: '' },
  taskProgress: { current: 0, total: 0, typeName: '' }
};

const $el = {
  pageTitle: $('#pageTitle'),
  modeTabs: $$('.mode-tab'),
  stateEmpty: $('#stateEmpty'),
  qaList: $('#qaList'),
  btnCapture: $('#btnCapture'),
  btnAnswer: $('#btnAnswer'),
  btnClear: $('#btnClear'),
  btnRefresh: $('#btnRefresh'),
  btnSettings: $('#btnSettings'),
  studyBtn: $('#studyBtn'),
  studyIcon: $('#studyIcon'),
  studyText: $('#studyText'),
  studyDot: $('#studyDot'),
  studyStatusText: $('#studyStatusText'),
  statVideos: $('#statVideos'),
  statQuizzes: $('#statQuizzes'),
  statChapters: $('#statChapters'),
  studyCard: $('#studyCard'),
  studyHints: $('#studyHints'),
  aiStatus: $('#aiStatus'),
  toastStack: $('#toastStack'),
  speedSelect: $('#speedSelect'),
  muteToggle: $('#muteToggle'),
  autoAnswerToggle: $('#autoAnswerToggle'),
  taskProgress: $('#studyTaskProgress'),
  taskProgressText: $('#taskProgressText'),
  taskProgressFill: $('#taskProgressFill'),
  panelLocal: $('#panelLocal'),
  panelAgent: $('#panelAgent'),
  panelCloud: $('#panelCloud'),
  localUrl: $('#localUrl'),
  localModel: $('#localModel'),
  agentUrl: $('#agentUrl'),
  cloudUrl: $('#cloudUrl'),
  cloudKey: $('#cloudKey'),
  cloudModel: $('#cloudModel'),
  cloudModelSelect: $('#cloudModelSelect'),
  btnFetchModels: $('#btnFetchModels')
};

// ==================== AI 检测 ====================

async function checkLocalAI(cfg) {
  state.aiStatus.checking = true;
  state.aiStatus.connected = false;
  state.aiStatus.models = [];
  state.aiStatus.modelHint = '检测 Ollama 中...';
  renderAIStatus();

  // 尝试多个常见地址
  const urls = [
    ((cfg || {}).local?.baseUrl || 'http://localhost:11434').replace(/\/+$/, ''),
    'http://localhost:11434',
    'http://127.0.0.1:11434'
  ];

  for (const url of urls) {
    try {
      // 尝试 Ollama 原生 API
      const res = await fetch(url + '/api/tags', { method: 'GET' });
      if (res.ok) {
        const data = await res.json();
        const models = (data.models || []).map(m => m.name || m.id);
        state.aiStatus.checking = false;
        state.aiStatus.connected = true;
        state.aiStatus.models = models;
        state.aiStatus.modelHint = models.length > 0 ? models[0] + (models.length > 1 ? ' +' + (models.length - 1) : '') : '已连接';
        renderAIStatus();
        return;
      }
    } catch (e) {
      // 继续尝试下一个地址
    }
  }

  state.aiStatus.checking = false;
  state.aiStatus.connected = false;
  state.aiStatus.models = [];
  state.aiStatus.modelHint = 'Ollama 未运行，请启动 ollama serve';
  renderAIStatus();
}

async function checkAgent(cfg) {
  state.aiStatus.checking = true;
  state.aiStatus.connected = false;
  state.aiStatus.modelHint = '检测 WSL Agent 中...';
  renderAIStatus();

  // Agent 通过 WSL 运行，默认地址
  const urls = [
    ((cfg || {}).wsl || cfg?.agent || {}).baseUrl || 'http://localhost:8787',
    'http://localhost:8787',
    'http://127.0.0.1:8787'
  ];

  for (const url of urls) {
    try {
      const res = await fetch(url + '/health', { method: 'GET', signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        state.aiStatus.checking = false;
        state.aiStatus.connected = true;
        state.aiStatus.modelHint = 'Agent 已连接 (' + url + ')';
        renderAIStatus();
        return;
      }
    } catch (e) {
      // 继续尝试
    }
  }

  state.aiStatus.checking = false;
  state.aiStatus.connected = false;
  state.aiStatus.modelHint = 'Agent 未运行，请启动 WSL Agent';
  renderAIStatus();
}

async function checkCloudAI(cfg) {
  const cloud = (cfg || {}).cloud || {};
  const url = (cloud.baseUrl || 'https://api.openai.com/v1').replace(/\/+$/, '');
  const key = cloud.apiKey || '';
  
  if (!key) {
    state.aiStatus.checking = false;
    state.aiStatus.connected = false;
    state.aiStatus.modelHint = '请填入 API 密钥';
    renderAIStatus();
    return;
  }

  state.aiStatus.checking = true;
  state.aiStatus.connected = false;
  state.aiStatus.modelHint = '检测云端 AI 中...';
  renderAIStatus();

  // 尝试多种协议
  const protocols = [
    { name: 'OpenAI', modelsPath: '/models', auth: 'Bearer ' + key },
    { name: 'Claude', modelsPath: '/models', auth: 'x-api-key: ' + key },
    { name: 'Gemini', modelsPath: '/models', auth: 'key=' + key }
  ];

  for (const proto of protocols) {
    try {
      const headers = {};
      if (proto.auth.startsWith('Bearer')) {
        headers['Authorization'] = proto.auth;
      } else if (proto.auth.startsWith('x-api-key')) {
        headers['x-api-key'] = key;
      }
      
      const res = await fetch(url + proto.modelsPath, { 
        method: 'GET', 
        headers: headers,
        signal: AbortSignal.timeout(5000)
      });
      
      if (res.ok) {
        const data = await res.json();
        const models = (data.data || []).map(m => m.id).filter(Boolean);
        state.aiStatus.checking = false;
        state.aiStatus.connected = true;
        state.aiStatus.models = models;
        state.aiStatus.modelHint = proto.name + ' 已连接' + (models.length > 0 ? ' (' + models[0] + ')' : '');
        renderAIStatus();
        return;
      } else if (res.status === 401 || res.status === 403) {
        state.aiStatus.checking = false;
        state.aiStatus.connected = false;
        state.aiStatus.modelHint = '认证失败，请检查密钥';
        renderAIStatus();
        return;
      } else if (res.status === 404) {
        // 404 表示接口存在但不暴露模型列表
        state.aiStatus.checking = false;
        state.aiStatus.connected = true;
        state.aiStatus.modelHint = proto.name + ' 已连接';
        renderAIStatus();
        return;
      }
    } catch (e) {
      // 继续尝试下一个协议
    }
  }

  state.aiStatus.checking = false;
  state.aiStatus.connected = false;
  state.aiStatus.modelHint = '无法连接，请检查地址和密钥';
  renderAIStatus();
}

function renderAIStatus() {
  const el = $el.aiStatus;
  if (!el) return;
  const s = state.aiStatus;
  el.hidden = false;
  if (s.checking) {
    el.innerHTML = '<span class="ai-status-dot busy"></span><span class="ai-status-text">' + escapeHTML(s.modelHint) + '</span>';
  } else if (s.connected) {
    el.innerHTML = '<span class="ai-status-dot ok"></span><span class="ai-status-text">' + escapeHTML(s.modelHint) + '</span>';
  } else {
    el.innerHTML = '<span class="ai-status-dot err"></span><span class="ai-status-text">' + escapeHTML(s.modelHint) + '</span>';
  }
}

// ==================== 云端模型列表获取 ====================

async function fetchCloudModels() {
  const url = ($el.cloudUrl?.value || '').replace(/\/+$/, '');
  const key = ($el.cloudKey?.value || '').trim();

  if (!url) { toast('请先填写 API 地址', 'info'); return; }
  if (!key) { toast('请先填写 API Key', 'info'); return; }

  $el.btnFetchModels.disabled = true;
  $el.btnFetchModels.textContent = '获取中...';

  try {
    const modelsUrl = url.replace(/\/v1\/?$/, '') + '/v1/models';
    const res = await fetch(modelsUrl, {
      method: 'GET',
      headers: { 'Authorization': 'Bearer ' + key },
      signal: AbortSignal.timeout(10000)
    });

    if (!res.ok) {
      if (res.status === 401 || res.status === 403) {
        toast('认证失败，请检查 API Key', 'error');
      } else {
        toast('获取模型失败: HTTP ' + res.status, 'error');
      }
      return;
    }

    const data = await res.json();
    const models = (data.data || []).map(m => m.id).filter(Boolean);

    if (models.length === 0) {
      toast('未返回任何模型', 'info');
      return;
    }

    // 填充下拉框
    const select = $el.cloudModelSelect;
    select.innerHTML = '';
    models.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m;
      opt.textContent = m;
      select.appendChild(opt);
    });

    // 如果当前有已选模型，选中它
    const currentModel = ($el.cloudModel?.value || '').trim();
    if (currentModel && models.includes(currentModel)) {
      select.value = currentModel;
    }

    // 切换显示：隐藏文本框，显示下拉框
    select.style.display = '';
    $el.cloudModel.style.display = 'none';

    // 选中模型时同步到文本框和配置
    select.addEventListener('change', () => {
      $el.cloudModel.value = select.value;
      saveCloudConfig();
    });

    toast('获取到 ' + models.length + ' 个模型', 'success');
  } catch (e) {
    toast('获取模型失败: ' + e.message, 'error');
  } finally {
    $el.btnFetchModels.disabled = false;
    $el.btnFetchModels.textContent = '获取';
  }
}

function saveCloudConfig() {
  self.SAStorage.getConfig().then(cfg => {
    const cloud = {
      ...(cfg.cloud || {}),
      baseUrl: $el.cloudUrl?.value?.trim() || '',
      apiKey: $el.cloudKey?.value?.trim() || '',
      model: $el.cloudModel?.value?.trim() || ''
    };
    return self.SAStorage.setConfig({ cloud });
  }).then(() => sendConfigReload()).catch(() => {});
}

// ==================== 初始化 ====================

async function init() {
  const cfg = await self.SAStorage.getConfig();
  state.mode = cfg.mode || 'local';
  state.cloudConfig = {
    baseUrl: (cfg.cloud || {}).baseUrl || '',
    apiKey: (cfg.cloud || {}).apiKey || '',
    model: (cfg.cloud || {}).model || ''
  };
  applyModeToUI(state.mode);
  
  const auto = cfg.automation || {};
  if ($el.speedSelect) $el.speedSelect.value = String(auto.playRate || '1');
  if ($el.muteToggle) $el.muteToggle.checked = auto.muteVideo !== false;
  if ($el.autoAnswerToggle) $el.autoAnswerToggle.checked = !!auto.autoAnswer;

  renderAIStatus();
  bindEvents();
  loadModeConfig(cfg);
  await refreshPageTitle();
  await requestAutoState();
  await requestPageInfo();

  // 启动时检测 AI 状态
  if (state.mode === 'local') checkLocalAI(cfg);
  else if (state.mode === 'agent') checkAgent(cfg);
  else if (state.mode === 'cloud') checkCloudAI(cfg);

  // 周期刷新
  state._pollTimer = setInterval(async () => {
    if (state._localToggle) return;
    await requestAutoState();
  }, 2000);

  chrome.runtime.onMessage.addListener(msg => {
    if (msg?.type === 'automation:state') {
      const p = msg.payload;
      if (p?.frameId) {
        state.autoFrames.set(p.frameId, p);
        aggregateFrames();
      }
      if (state._localToggle) state._localToggle = null;
      renderAutoState();
    }
  });

  log.info('SidePanel', 'initialized with mode', state.mode);
}

function applyModeToUI(mode) {
  $el.modeTabs.forEach(t => t.classList.toggle('active', t.dataset.mode === mode));
  if ($el.panelLocal) $el.panelLocal.hidden = mode !== 'local';
  if ($el.panelAgent) $el.panelAgent.hidden = mode !== 'agent';
  if ($el.panelCloud) $el.panelCloud.hidden = mode !== 'cloud';
}

function loadModeConfig(cfg) {
  if ($el.localUrl) $el.localUrl.value = (cfg.local || {}).baseUrl || 'http://localhost:11434';
  if ($el.localModel) $el.localModel.value = (cfg.local || {}).model || '';
  if ($el.agentUrl) $el.agentUrl.value = ((cfg.wsl || cfg.agent) || {}).baseUrl || 'http://localhost:8787';
  if ($el.cloudUrl) $el.cloudUrl.value = (cfg.cloud || {}).baseUrl || 'https://api.openai.com/v1';
  if ($el.cloudKey) $el.cloudKey.value = (cfg.cloud || {}).apiKey || '';
  if ($el.cloudModel) $el.cloudModel.value = (cfg.cloud || {}).model || '';
}

function bindEvents() {
  $el.modeTabs.forEach(tab => {
    tab.addEventListener('click', async () => {
      const newMode = tab.dataset.mode;
      if (newMode === state.mode) return;
      state.mode = newMode;
      applyModeToUI(newMode);
      renderAIStatus();
      self.SAStorage.setConfig({ mode: newMode });
      toast('已切换到 ' + tab.textContent.trim(), 'info');
      
      const cfg = await self.SAStorage.getConfig();
      if (newMode === 'local') checkLocalAI(cfg);
      else if (newMode === 'agent') checkAgent(cfg);
      else if (newMode === 'cloud') checkCloudAI(cfg);
    });
  });

  $el.btnCapture.addEventListener('click', captureQuestions);
  $el.btnAnswer.addEventListener('click', answerAll);
  $el.btnClear.addEventListener('click', clearAll);

  $el.btnRefresh.addEventListener('click', async () => {
    $el.btnRefresh.classList.add('spinning');
    await refreshPageTitle();
    await requestAutoState();
    await requestPageInfo();
    setTimeout(() => $el.btnRefresh.classList.remove('spinning'), 700);
    toast('已刷新', 'success');
  });

  $el.btnSettings.addEventListener('click', () => {
    chrome.runtime.openOptionsPage?.();
  });

  if ($el.speedSelect) {
    $el.speedSelect.addEventListener('change', () => {
      const rate = parseFloat($el.speedSelect.value) || 1.5;
      self.SAStorage.getConfig().then(cfg => {
        const auto = { ...(cfg.automation || {}), playRate: rate };
        self.SAStorage.setConfig({ automation: auto });
      }).then(() => sendConfigReload()).catch(() => {});
    });
  }

  if ($el.muteToggle) {
    $el.muteToggle.addEventListener('change', () => {
      const muted = $el.muteToggle.checked;
      self.SAStorage.getConfig().then(cfg => {
        const auto = { ...(cfg.automation || {}), muteVideo: muted };
        self.SAStorage.setConfig({ automation: auto });
      }).then(() => sendConfigReload()).catch(() => {});
    });
  }

  if ($el.autoAnswerToggle) {
    $el.autoAnswerToggle.addEventListener('change', () => {
      const enabled = $el.autoAnswerToggle.checked;
      self.SAStorage.getConfig().then(cfg => {
        const auto = { ...(cfg.automation || {}), autoAnswer: enabled, autoSubmit: enabled };
        self.SAStorage.setConfig({ automation: auto });
      }).then(() => sendConfigReload()).catch(() => {});
    });
  }

  // 模式配置输入监听
  const modeInputHandler = async () => {
    const cfg = await self.SAStorage.getConfig();
    const patch = {};
    if ($el.localUrl) patch.local = { ...(cfg.local || {}), baseUrl: $el.localUrl.value.trim() };
    if ($el.localModel) patch.local = { ...(patch.local || cfg.local || {}), model: $el.localModel.value.trim() };
    if ($el.agentUrl) patch.wsl = { ...(cfg.wsl || {}), baseUrl: $el.agentUrl.value.trim() };
    if ($el.cloudUrl) patch.cloud = { ...(cfg.cloud || {}), baseUrl: $el.cloudUrl.value.trim() };
    if ($el.cloudKey) patch.cloud = { ...(patch.cloud || cfg.cloud || {}), apiKey: $el.cloudKey.value.trim() };
    if ($el.cloudModel) patch.cloud = { ...(patch.cloud || cfg.cloud || {}), model: $el.cloudModel.value.trim() };
    await self.SAStorage.setConfig(patch);
    sendConfigReload();
    // 重新检测 AI 状态
    const newCfg = await self.SAStorage.getConfig();
    if (state.mode === 'local') checkLocalAI(newCfg);
    else if (state.mode === 'agent') checkAgent(newCfg);
    else if (state.mode === 'cloud') checkCloudAI(newCfg);
  };
  [$el.localUrl, $el.localModel, $el.agentUrl, $el.cloudUrl, $el.cloudKey, $el.cloudModel].forEach(el => {
    if (el) el.addEventListener('change', modeInputHandler);
  });

  if ($el.btnFetchModels) {
    $el.btnFetchModels.addEventListener('click', fetchCloudModels);
  }

  // 模型输入框：用户手动输入时隐藏下拉框，切回文本输入
  if ($el.cloudModel) {
    $el.cloudModel.addEventListener('input', () => {
      if ($el.cloudModelSelect && $el.cloudModelSelect.style.display !== 'none') {
        $el.cloudModelSelect.style.display = 'none';
        $el.cloudModel.style.display = '';
      }
    });
  }

  $el.studyBtn.addEventListener('click', () => {
    const newEnabled = !state.autoState.enabled;
    state.autoState.enabled = newEnabled;
    state.autoState.running = newEnabled;
    if (!newEnabled) state.autoFrames.clear();
    state._localToggle = 'pending';
    renderAutoState();

    self.SAStorage.getConfig().then(cfg => {
      self.SAStorage.setConfig({
        automation: { ...cfg.automation, autoSkipVideo: newEnabled }
      });
    }).catch(() => {});

    chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
      if (!tab?.id) return;
      chrome.tabs.sendMessage(tab.id, { type: 'automation:toggle', payload: { enabled: newEnabled } }).catch(() => {});
    }).catch(() => {});

    if (state._localToggleReset) clearTimeout(state._localToggleReset);
    state._localToggleReset = setTimeout(() => {
      if (state._localToggle) {
        state._localToggle = null;
        renderAutoState();
      }
    }, 5000);

    toast(newEnabled ? '自动学习已启动' : '自动学习已停止', newEnabled ? 'success' : 'info');
  });
}

// ==================== 自动学习状态 ====================

async function requestAutoState() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab?.id) return;
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'automation:getState' });
    if (r?.frameId) {
      state.autoFrames.set(r.frameId, r);
      aggregateFrames();
      renderAutoState();
    }
  } catch (e) {}
}

function aggregateFrames() {
  let runningCount = 0, enabledCount = 0;
  let totalWatched = 0, totalQuizzes = 0, totalChapters = 0;
  let topFrame = null;
  for (const p of state.autoFrames.values()) {
    if (p.running) runningCount++;
    if (p.enabled) enabledCount++;
    if (p.stats) {
      totalWatched += p.stats.videoWatched || 0;
      totalQuizzes += p.stats.quizAnswered || 0;
      totalChapters += p.stats.chaptersDone || 0;
    }
    if (p.isTop) topFrame = p;
  }
  state.autoState = {
    ...state.autoState,
    runningFrames: runningCount,
    enabledFrames: enabledCount,
    frameCount: state.autoFrames.size,
    stats: { videoWatched: totalWatched, quizAnswered: totalQuizzes, chaptersDone: totalChapters },
    taskQueue: topFrame?.taskQueue || null
  };
}

async function requestPageInfo() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab?.id) return;
    let data;
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { type: 'page:info' });
      data = r?.ok && r.data ? r.data : r;
    } catch (e1) {
      try { data = await self.SAMessage.send('page:info'); } catch (e2) { renderHints(null); return; }
    }
    renderHints(data || null);
  } catch (e) { renderHints(null); }
}

function renderHints(info) {
  const el = $el.studyHints;
  if (!el) return;
  if (!info) { el.hidden = true; el.innerHTML = ''; return; }
  if (info.isLogin) {
    el.hidden = false;
    el.className = 'study-hints study-hints-warn';
    el.innerHTML = '<div class="study-hints-title">请先登录</div>'
      + info.hints.map(h => '<div class="study-hints-item">· ' + escapeHTML(h) + '</div>').join('');
  } else {
    el.hidden = false;
    el.className = 'study-hints study-hints-ok';
    el.innerHTML = '<div class="study-hints-title">就绪</div>'
      + info.hints.map(h => '<div class="study-hints-item">· ' + escapeHTML(h) + '</div>').join('');
  }
}

function renderAutoState() {
  const s = state.autoState;
  const isRunning = !!s.running;
  const isEnabled = !!s.enabled;

  if (isRunning) {
    $el.studyBtn.classList.add('running');
    $el.studyIcon.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>';
    $el.studyText.textContent = '停止学习';
  } else {
    $el.studyBtn.classList.remove('running');
    $el.studyIcon.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
    $el.studyText.textContent = isEnabled ? '启动中...' : '开始自动学习';
  }

  if (isRunning) {
    $el.studyDot.classList.add('running');
    $el.studyStatusText.textContent = '运行中';
  } else if (isEnabled) {
    $el.studyDot.classList.remove('running');
    $el.studyStatusText.textContent = '已启用';
  } else {
    $el.studyDot.classList.remove('running');
    $el.studyStatusText.textContent = '未启动';
  }

  $el.statVideos.textContent = s.stats?.videoWatched || 0;
  $el.statQuizzes.textContent = s.stats?.quizAnswered || 0;
  $el.statChapters.textContent = s.stats?.chaptersDone || 0;

  const tq = s.taskQueue;
  if (tq && tq.total > 0 && tq.running) {
    const done = Math.min(tq.current, tq.total);
    const pct = Math.round((done / tq.total) * 100);
    $el.taskProgressText.textContent = '任务进度：' + done + '/' + tq.total;
    $el.taskProgressFill.style.width = pct + '%';
    $el.taskProgress.hidden = false;
  } else if ($el.taskProgress) {
    $el.taskProgress.hidden = true;
  }
}

async function refreshPageTitle() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab) {
      $el.pageTitle.textContent = (tab.title || '当前页').slice(0, 22);
      $el.pageTitle.title = tab.url || '';
    } else {
      $el.pageTitle.textContent = '未连接';
    }
  } catch (e) {
    $el.pageTitle.textContent = '未连接';
  }
}

// ==================== 题目捕获与解答 ====================

async function captureQuestions() {
  if (state.isCapturing) return;
  state.isCapturing = true;
  $el.btnCapture.disabled = true;
  try {
    toast('正在捕获题目...', 'info');
    const res = await self.SAMessage.sendToActiveTab('content:extractQuestions', {});
    if (!res?.questions?.length) {
      toast('当前页面未发现题目', 'info');
      return;
    }
    state.questions = res.questions;
    renderQuestions();
    toast('捕获到 ' + res.questions.length + ' 道题', 'success');
  } catch (e) {
    toast('捕获失败：' + e.message, 'error');
  } finally {
    state.isCapturing = false;
    $el.btnCapture.disabled = false;
  }
}

function renderQuestions() {
  if (!state.questions.length) {
    $el.qaList.hidden = true;
    $el.stateEmpty.hidden = false;
    return;
  }
  $el.stateEmpty.hidden = true;
  $el.qaList.hidden = false;
  $el.qaList.innerHTML = '';
  state.questions.forEach((q, idx) => {
    const card = document.createElement('div');
    card.className = 'q-card';
    card.innerHTML = `
      <div class="q-stem">${idx + 1}. ${escapeHTML(q.stem || '(无题干)')}</div>
      ${renderOptions(q)}
      <div class="q-answer ${q.answer ? '' : 'loading'}" data-qid="${q.id}">
        ${q.answer
          ? '<span class="q-answer-text">' + escapeHTML(q.answer) + '</span>'
          : '<span class="spinner"></span><span class="q-answer-text">正在解答...</span>'}
      </div>
      <div class="q-actions">
        <button class="q-action" data-act="answer">解答</button>
        <button class="q-action" data-act="copy">复制</button>
        <button class="q-action" data-act="remove">删除</button>
      </div>
    `;
    card.querySelectorAll('.q-action').forEach(btn => {
      btn.addEventListener('click', () => onQAction(q.id, btn.dataset.act));
    });
    $el.qaList.appendChild(card);
  });
}

function renderOptions(q) {
  if (!q.options?.length) return '';
  return '<div class="q-options">' +
    q.options.map(o => {
      const isCorrect = q.correctKey && o.key === q.correctKey;
      return '<div class="q-option ' + (isCorrect ? 'correct' : '') + '">' +
        '<span class="q-option-key">' + escapeHTML(o.key) + '.</span>' +
        '<span>' + escapeHTML(o.text || '') + '</span>' +
        '</div>';
    }).join('') +
    '</div>';
}

async function onQAction(qid, act) {
  const idx = state.questions.findIndex(q => q.id === qid);
  if (idx < 0) return;
  if (act === 'answer') {
    await answerOne(qid);
  } else if (act === 'copy') {
    const q = state.questions[idx];
    const txt = (q.stem || '') + '\n' + (q.options || []).map(o => o.key + '. ' + o.text).join('\n');
    try { await navigator.clipboard.writeText(txt); toast('已复制', 'success'); }
    catch (e) { toast('复制失败', 'error'); }
  } else if (act === 'remove') {
    state.questions.splice(idx, 1);
    renderQuestions();
  }
}

async function answerAll() {
  if (!state.questions.length) { toast('请先捕获题目', 'info'); return; }
  const pending = state.questions.filter(q => !q.answer);
  if (!pending.length) { toast('已全部解答', 'info'); return; }
  toast('正在解答 ' + pending.length + ' 道题...', 'info');
  for (const q of pending) await answerOne(q.id);
  toast('全部完成', 'success');
}

async function answerOne(qid) {
  const q = state.questions.find(x => x.id === qid);
  if (!q) return;
  const answerBox = document.querySelector('.q-answer[data-qid="' + qid + '"]');
  if (answerBox) {
    answerBox.classList.remove('loading');
    answerBox.innerHTML = '<span class="spinner"></span><span class="q-answer-text">解答中...</span>';
  }
  try {
    const res = await self.SAMessage.send('ai:answer', { question: q });
    q.answer = res.answer || res.text || '(无返回)';
    q.correctKey = (q.answer.match(/答案[:：]?\s*([A-Z])/i) || [])[1];
    renderQuestions();
  } catch (e) {
    if (answerBox) {
      answerBox.classList.add('loading');
      answerBox.innerHTML = '<span class="q-answer-text" style="color:var(--danger)">失败：' + escapeHTML(e.message) + '</span>';
    }
    toast('解答失败：' + e.message, 'error');
  }
}

function clearAll() {
  if (!state.questions.length) return;
  state.questions = [];
  renderQuestions();
  toast('已清空', 'info');
}

function toast(msg, type = 'info') {
  const t = document.createElement('div');
  t.className = 'toast toast-' + type;
  t.textContent = msg;
  $el.toastStack.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}

function sendConfigReload() {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { type: 'automation:config' }).catch(() => {});
  }).catch(() => {});
}

function escapeHTML(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

document.addEventListener('DOMContentLoaded', init);
})();
