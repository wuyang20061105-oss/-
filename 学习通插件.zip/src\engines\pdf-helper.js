/**
* PDF 解析辅助（service worker 端）
* - 由于 service worker 不能直接使用页面 PDF.js
* - 改为解析时直接 fetch + 简易文本提取（流式）
* - 对于扫描件 PDF，需要 WSL Agent / Local AI 提供 OCR 能力
*/

let pdfjsLib =null;
async function ensurePdfjs() {
if (pdfjsLib)return pdfjsLib;
pdfjsLib = await import(chrome.runtime.getURL('src/assets/pdfjs/pdf.min.mjs'));
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('src/assets/pdfjs/pdf.worker.min.mjs');
return pdfjsLib;
}

export async function extractFromArrayBuffer(bytes) {
const lib = await ensurePdfjs();
const pdf = await lib.getDocument({ data: bytes }).promise;
const total = Math.min(pdf.numPages, 200);
const pages = [];
for (let i = 1; i <= total; i++) {
const page = await pdf.getPage(i);
const content = await page.getTextContent();
const text = content.items.map(it => it.str).join(' ');
pages.push({ page: i, text });
}
return {
totalPages: pdf.numPages,
extracted: total,
pages,
fullText: pages.map(p => p.text).join('\n\n')
};
}
