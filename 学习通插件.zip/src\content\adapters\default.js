/**
* 通用网页适配器
* - 不识别为学习通时的兜底
* - 提供：选中文本、阅读模式正文提取
*/
(function (global) {
'use strict';

const { $, $$, cleanText } = global.SADom;

const DefaultAdapter = {
name: 'default',
match() {return true; },

async onEnter() {},
onLeave() {},

getPageInfo() {
return { host: location.host, path: location.pathname, title: document.title, url: location.href };
},

async extractQuestions() {
// 策略：用户主动框选 -> 视为题目；否则取页面正文摘要
const selection = window.getSelection()?.toString() || '';
if (selection.trim().length > 5) {
return [{
id:`sel_${Date.now()}`,
type: 'user-selected',
stem: cleanText(selection),
options: [],
source: this.getPageInfo()
}];
}
// 退化：取 <main> / <article> / 最大段落块
const main = $('main, article, #content, #main') || document.body;
return [{
id:`page_${Date.now()}`,
type: 'page-content',
stem: cleanText(main.innerText).slice(0, 4000),
options: [],
source: this.getPageInfo()
}];
},

startObserving() {},
async runAction(action, args) {
if (action === 'copySelection') {
const text = window.getSelection()?.toString() || '';
await navigator.clipboard.writeText(text);
return { text };
}
return false;
}
};

global.SADefaultAdapter = DefaultAdapter;
})(typeof self !== 'undefined' ? self : globalThis);
