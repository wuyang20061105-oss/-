/**
 * 本地 AI 引擎 (v2.0)
 *
 * 统一使用 OpenAI Chat Completions 协议：
 *   POST {baseUrl}/v1/chat/completions
 *
 * 自动检测可用模型，优先选择轻量模型
 * 超时: 10分钟
 */
import { BaseEngine } from './base.js';

export class LocalAIEngine extends BaseEngine {
  constructor(cfg) {
    super(cfg);
    this.baseUrl = (cfg.baseUrl || 'http://localhost:11434').replace(/\/+$/, '');
    this.apiKey = cfg.apiKey || 'ollama';
    this.model = cfg.model || '';
    this.temperature = Number(cfg.temperature ?? 0.2);
    this.maxTokens = Number(cfg.maxTokens ?? 2048);
    this.systemPrompt = cfg.systemPrompt || '你是一个严谨的大学网课助教。';
    this.timeoutMs = 600000;
    this.detectedModels = [];
  }

  _headers() {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.apiKey}`
    };
  }

  _messages(question) {
    const msgs = [{ role: 'system', content: this.systemPrompt }];
    msgs.push({ role: 'user', content: this.buildPrompt(question) });
    return msgs;
  }

  async detectModels() {
    try {
      const res = await fetch(`${this.baseUrl}/api/tags`, {
        signal: AbortSignal.timeout(5000)
      });
      if (!res.ok) return [];
      const data = await res.json();
      this.detectedModels = (data.models || []).map(m => m.name);
      return this.detectedModels;
    } catch {
      return [];
    }
  }

  async ensureModel() {
    if (this.model && this.detectedModels.includes(this.model)) {
      return this.model;
    }

    const models = await this.detectModels();
    if (models.length === 0) return null;

    const preferred = ['qwen2.5:3b', 'qwen2.5:7b', 'qwen2.5:14b', 'qwen2.5:32b', 'gemma4:31b', 'llama3.1:8b', 'mistral:7b'];
    for (const p of preferred) {
      if (models.includes(p)) { this.model = p; return p; }
    }
    this.model = models[0];
    return models[0];
  }

  async answer(question, history) {
    const model = await this.ensureModel();
    if (!model) throw new Error('未检测到可用的Ollama模型');

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify({
          model,
          messages: this._messages(question),
          temperature: this.temperature,
          max_tokens: this.maxTokens,
          stream: false
        }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`local AI ${res.status}`);
      const data = await res.json();
      const answer = data?.choices?.[0]?.message?.content || '';
      return { answer, raw: data };
    } catch (e) {
      clearTimeout(timer);
      throw e;
    }
  }

  async *streamAnswer(question, history, abort) {
    const model = await this.ensureModel();
    if (!model) throw new Error('无可用模型');

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    if (typeof abort === 'function') {
      const check = setInterval(() => abort() && ctrl.abort(), 500);
      ctrl.signal.addEventListener('abort', () => clearInterval(check));
    }
    try {
      const res = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: { ...this._headers(), Accept: 'text/event-stream' },
        body: JSON.stringify({
          model,
          messages: this._messages(question),
          temperature: this.temperature,
          max_tokens: this.maxTokens,
          stream: true
        }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`stream ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      while (true) {
        if (abort?.()) return;
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          const s = line.trim();
          if (!s.startsWith('data:')) continue;
          const payload = s.slice(5).trim();
          if (payload === '[DONE]') return;
          try {
            const json = JSON.parse(payload);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) yield delta;
          } catch {}
        }
      }
    } finally {
      clearTimeout(timer);
    }
  }
}
