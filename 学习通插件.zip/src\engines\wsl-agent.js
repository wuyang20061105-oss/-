/**
 * Agent 引擎 (v2.0)
 *
 * 多端口自动探测 + OpenAI Chat Completions 统一协议
 *
 * 探测端口: 8787, 3000, 8080, 5000, 11434, 1234, 8000
 * 接口: POST {endpoint}/v1/chat/completions
 *
 * 兼容 OpenCode / 任何 OpenAI 兼容服务
 * 如果所有端口探测失败，回退到本地 Ollama
 */
import { BaseEngine } from './base.js';

export class WslAgentEngine extends BaseEngine {
  constructor(cfg) {
    super(cfg);
    this.baseUrl = (cfg.baseUrl || 'http://localhost:8787').replace(/\/+$/, '');
    this.apiKey = cfg.apiKey || '';
    this.agentName = cfg.agentName || 'study-agent';
    this.timeoutMs = Number(cfg.timeoutMs ?? 600000);
    this.probePorts = cfg.probePorts || [8787, 3000, 8080, 5000, 11434, 1234, 8000];
    this.resolvedEndpoint = '';
  }

  _headers() {
    return {
      'Content-Type': 'application/json',
      ...(this.apiKey ? { Authorization: `Bearer ${this.apiKey}` } : {})
    };
  }

  _messages(question) {
    const msgs = [{ role: 'system', content: this.cfg.systemPrompt || '你是一个严谨的大学网课助教。' }];
    msgs.push({ role: 'user', content: this.buildPrompt(question) });
    return msgs;
  }

  async probePort(port) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 2000);
      const res = await fetch(`http://localhost:${port}/v1/models`, {
        method: 'GET',
        signal: ctrl.signal
      });
      clearTimeout(timer);
      return res.ok;
    } catch {
      return false;
    }
  }

  async detectEndpoint() {
    if (this.resolvedEndpoint) return this.resolvedEndpoint;

    for (const port of this.probePorts) {
      if (await this.probePort(port)) {
        this.resolvedEndpoint = `http://localhost:${port}`;
        return this.resolvedEndpoint;
      }
    }
    return null;
  }

  async answer(question, history) {
    const endpoint = await this.detectEndpoint();
    if (!endpoint) throw new Error('Agent不可用: 所有端口探测失败');

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    try {
      const res = await fetch(`${endpoint}/v1/chat/completions`, {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify({
          model: this.agentName,
          messages: this._messages(question),
          stream: false,
          temperature: 0.2,
          max_tokens: 2048
        }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`agent ${res.status}`);
      const data = await res.json();
      const answer = data?.choices?.[0]?.message?.content || '';
      return { answer, raw: data, endpoint };
    } catch (e) {
      clearTimeout(timer);
      throw e;
    }
  }

  async *streamAnswer(question, history, abort) {
    const endpoint = await this.detectEndpoint();
    if (!endpoint) throw new Error('Agent不可用');

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    if (typeof abort === 'function') {
      const check = setInterval(() => abort() && ctrl.abort(), 500);
      ctrl.signal.addEventListener('abort', () => clearInterval(check));
    }
    try {
      const res = await fetch(`${endpoint}/v1/chat/completions`, {
        method: 'POST',
        headers: { ...this._headers(), Accept: 'text/event-stream' },
        body: JSON.stringify({
          model: this.agentName,
          messages: this._messages(question),
          stream: true,
          temperature: 0.2,
          max_tokens: 2048
        }),
        signal: ctrl.signal
      });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`agent stream ${res.status}`);

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buffer = '';
      while (true) {
        if (abort?.()) return;
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          const s = line.trim();
          if (!s.startsWith('data:')) continue;
          const payload = s.slice(5).trim();
          if (payload === '[DONE]') return;
          try {
            const json = JSON.parse(payload);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) yield delta;
          } catch {}
        }
      }
    } finally {
      clearTimeout(timer);
    }
  }
}
