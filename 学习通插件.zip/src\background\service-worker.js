/**
 * Background Service Worker (MV3)
 *
 * 职责：
 * 1. 程序化注入 content script（兜底一切 match pattern 失效）
 * 2. 路由：sidepanel / popup / content 之间的消息总线
 * 3. 调度：根据用户配置选择 AI 引擎（thirdparty / local / wsl）
 * 4. 副作用：打开侧边栏、读取当前 tab、维护长连接
 */
import { ThirdpartyEngine } from '../engines/thirdparty.js';
import { LocalAIEngine } from '../engines/local-ai.js';
import { WslAgentEngine } from '../engines/wsl-agent.js';
import { CloudAIEngine } from '../engines/cloud-ai.js';

// ============= 默认配置 =============
const DEFAULT_CONFIG = {
  mode: 'local',
  thirdparty: { provider: 'soutijiang', token: '', cookie: '', endpoint: 'https://api.universitysouti.com/v1/question/search' },
  local: { baseUrl: 'http://localhost:11434/v1', apiKey: 'ollama', model: '', temperature: 0.2, maxTokens: 2048, systemPrompt: '你是一个严谨的大学网课助教，请给出准确答案与详细解析步骤。' },
  wsl: { baseUrl: 'http://localhost:8787', apiKey: '', agentName: 'study-agent', timeoutMs: 60000 },
  cloud: { baseUrl: 'https://api.openai.com/v1', apiKey: '', model: 'gpt-4o-mini', temperature: 0.2, maxTokens: 2048 },
  ui: { autoOpen: true, showFloatingBall: true, ballPosition: 'right-middle' },
  automation: { autoSkipVideo: false, muteVideo: true, playRate: 1, autoAnswer: false, autoSubmit: false }
};

// ============= 需要注入 content script 的目标域名 =============
const TARGET_HOSTS = [
  'chaoxing.com',
  'zhihuishan.com',
  'xuetangx.com'
];

function isTargetUrl(url) {
  if (!url || !url.startsWith('http')) return false;
  try {
    const host = new URL(url).hostname;
    return TARGET_HOSTS.some(h => host === h || host.endsWith('.' + h));
  } catch { return false; }
}

// ============= 程序化注入 content script =============
const CS_FILES = [
  'src/utils/logger.js',
  'src/utils/storage.js',
  'src/utils/dom.js',
  'src/utils/message.js',
  'src/content/ui/floating-ball.js',
  'src/content/adapters/chaoxing.js',
  'src/content/adapters/default.js',
  'src/content/adapters/index.js',
  'src/content/pdf/pdf-extractor.js',
  'src/content/automation/automation.js',
  'src/content/video.js',
  'src/content/doc.js',
  'src/content/solver.js',
  'src/content/content.js'
];
const CS_CSS = ['src/content/ui/shadow-host.css'];

async function injectContentScripts(tabId) {
  try {
    for (const css of CS_CSS) {
      await chrome.scripting.insertCSS({ target: { tabId, allFrames: true }, files: [css] }).catch(() => {});
    }
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: CS_FILES
    });
  } catch (e) {
    console.warn('[SA:SW] inject failed:', e.message);
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.url) return;
  if (isTargetUrl(tab.url)) {
    injectContentScripts(tabId);
  }
});

// ============= 引擎单例（懒加载） =============
const engines = { thirdparty: null, local: null, wsl: null, cloud: null };
function getEngine(mode, cfg) {
  switch (mode) {
    case 'thirdparty': return (engines.thirdparty ??= new ThirdpartyEngine(cfg));
    case 'local': return (engines.local ??= new LocalAIEngine(cfg));
    case 'wsl':
    case 'agent': return (engines.wsl ??= new WslAgentEngine(cfg));
    case 'cloud': return (engines.cloud ??= new CloudAIEngine(cfg));
    default: throw new Error(`unknown mode: ${mode}`);
  }
}

async function getActiveEngine() {
  const { sa_config_v1: config } = await chrome.storage.local.get(['sa_config_v1']);
  if (!config) throw new Error('配置未初始化');
  const engineConfigKey = config.mode === 'agent' ? 'wsl' : config.mode;
  return getEngine(config.mode, config[engineConfigKey]);
}

// ============= 消息路由 =============
const handlers = new Map();
function on(type, handler) { handlers.set(type, handler); }

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      const { type, payload, requestId } = msg || {};
      const fn = handlers.get(type);
      if (!fn) return sendResponse({ ok: false, error: `no handler: ${type}`, requestId });
      const data = await fn(payload, sender);
      sendResponse({ ok: true, data, requestId });
    } catch (err) {
      console.error('[SA:SW]', err);
      sendResponse({ ok: false, error: err.message });
    }
  })();
  return true;
});

// ----- 基础消息 -----
on('tab:current', async (_p, sender) => {
  const tabId = sender?.tab?.id;
  if (tabId) return chrome.tabs.get(tabId);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
});

on('sidepanel:open', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.windowId) return false;
  await chrome.sidePanel.open({ windowId: tab.windowId });
  return true;
});

on('sidepanel:captureNow', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('no active tab');
  return chrome.tabs.sendMessage(tab.id, { type: 'content:extractQuestions' });
});

on('sidepanel:pushResult', async (payload) => {
  chrome.runtime.sendMessage({ type: 'sidepanel:onResult', payload }).catch(() => {});
});

// ----- 核心：AI 解析（可选，AI 未部署时不会调用到） -----
on('ai:answer', async ({ question, history }) => {
  const engine = await getActiveEngine();
  return engine.answer(question, history);
});

// 流式输出
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'sa-stream') return;
  let aborted = false;
  let requestData = null;
  port.onDisconnect.addListener(() => { aborted = true; });
  port.onMessage.addListener(msg => {
    if (msg?.type === 'start') {
      requestData = msg;
    }
  });
  (async () => {
    try {
      const engine = await getActiveEngine();
      const question = requestData?.question;
      const history = requestData?.history;
      if (!question) {
        port.postMessage({ type: 'error', error: '缺少 question 参数' });
        return;
      }
      const stream = engine.streamAnswer(question, history, () => aborted);
      for await (const chunk of stream) {
        if (aborted) break;
        try { port.postMessage({ type: 'chunk', data: chunk }); } catch { break; }
      }
      port.postMessage({ type: 'done' });
    } catch (e) {
      try { port.postMessage({ type: 'error', error: e.message }); } catch {}
    }
  })();
});

// ----- 代理 fetch（解决 HTTPS 页面无法访问 HTTP localhost 的问题） -----
on('proxy:fetch', async ({ url, options }) => {
  try {
    const res = await fetch(url, options);
    let body;
    try {
      body = await res.json();
    } catch {
      body = await res.text();
    }
    return { status: res.status, ok: res.ok, body };
  } catch (e) {
    return { status: 0, ok: false, body: null, error: e.message };
  }
});

// ----- 内容脚本事件转发给 side panel -----
on('adapter:event', async (payload) => {
  chrome.runtime.sendMessage({ type: 'sidepanel:onAdapterEvent', payload }).catch(() => {});
  return true;
});

on('automation:state', async (payload) => {
  chrome.runtime.sendMessage({ type: 'automation:state', payload }).catch(() => {});
  return true;
});

on('override-confirm', async (_payload, sender) => {
  const tabId = sender?.tab?.id;
  if (!tabId) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        world: 'MAIN',
        func: () => {
          window.confirm = () => true;
          window.alert = () => {};
        }
      });
    }
  } else {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: 'MAIN',
      func: () => {
        window.confirm = () => true;
        window.alert = () => {};
      }
    });
  }
  return true;
});

// ----- 转发 page:info 到 content script -----
on('page:info', async (_payload, sender) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error('no active tab');
  return chrome.tabs.sendMessage(tab.id, { type: 'page:info' });
});

// ============= 快捷键 =============
chrome.commands.onCommand.addListener(async cmd => {
  if (cmd === 'open-side-panel') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.windowId) await chrome.sidePanel.open({ windowId: tab.windowId });
  }
  if (cmd === 'capture-question') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: 'content:extractQuestions' });
  }
});

// ============= 安装事件 =============
chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(['sa_config_v1']);
  if (!cur.sa_config_v1) {
    await chrome.storage.local.set({ sa_config_v1: DEFAULT_CONFIG });
  }
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  // 注入已打开的目标页面
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.url && isTargetUrl(tab.url)) {
      injectContentScripts(tab.id);
    }
  }
});
