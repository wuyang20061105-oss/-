/**
 * 超星学习通适配器
 *
 * 核心功能：
 * 1. 穿透 iframe 提取题目和视频状态
 * 2. 解析 mArg 对象获取任务点状态
 * 3. 自动静音/倍速播放视频
 * 4. 防暂停恢复机制
 */
(function (global) {
  'use strict';

  var $ = global.SADom.$;
  var $$ = global.SADom.$$;
  var cleanText = global.SADom.cleanText;
  var log = global.SALogger;

  // 选择器配置（学习通改版时只需改这里）
  var SEL = {
    questionContainer: '.TiMu, .question-item, .Zy_TItle, .topic',
    questionTitle: '.Zy_TItle .clearfix, .topic-title, .question-title',
    questionOptions: '.Zy_ulTop li, .topic-options li, .option-list li',
    questionType: '.Zy_TItle .icon, .topic-type',
    dialog: '.layui-layer, .topic-dialog, .el-dialog',
    confirmBtn: '.layui-layer-btn0, .bluebtn, .sure'
  };

  var ChaoxingAdapter = {
    name: 'chaoxing',
    _observer: null,
    _pollingTimers: [],

    // 匹配学习通域名
    match(host) {
      return /chaoxing\.com|zhihuishan\.com|xuetangx\.com/.test(host);
    },

    // 进入页面：启动观察
    async onEnter() {
      this.startObserving();
      this.startVideoHook();
    },

    onLeave() {
      if (this._observer) { this._observer.disconnect(); this._observer = null; }
      this._pollingTimers.forEach(function(t) { clearInterval(t); });
      this._pollingTimers = [];
    },

    getPageInfo() {
      return {
        host: location.host,
        path: location.pathname,
        title: document.title,
        url: location.href
      };
    },

    // ==================== 提取题目 ====================
    async extractQuestions() {
      var questions = [];
      var self = this;

      // 遍历 iframe 提取题目
      $$('iframe').forEach(function(fr) {
        try {
          var doc = fr.contentDocument;
          if (!doc) return;
          $$(SEL.questionContainer, doc).forEach(function(el) {
            var q = self._parseQuestion(el, doc);
            if (q) questions.push(q);
          });
        } catch (e) {}
      });

      // 当前提取题目
      $$(SEL.questionContainer).forEach(function(el) {
        var q = self._parseQuestion(el, document);
        if (q) questions.push(q);
      });

      return questions;
    },

    _parseQuestion(node) {
      try {
        var titleEl = $(SEL.questionTitle, node) || node;
        var stem = cleanText(titleEl.textContent);
        if (!stem || stem.length < 2) return null;

        // 题型判断
        var typeEl = $(SEL.questionType, node);
        var typeText = cleanText(typeEl ? typeEl.textContent : '');
        var type = 'unknown';
        if (/单选/.test(typeText)) type = 'single';
        else if (/多选/.test(typeText)) type = 'multiple';
        else if (/判断|对错/.test(typeText)) type = 'judge';
        else if (/填空/.test(typeText)) type = 'fill';
        else if (/简答|问答/.test(typeText)) type = 'essay';

        // 选项
        var options = $$(SEL.questionOptions, node).map(function(el, i) {
          return {
            key: String.fromCharCode(65 + i),
            text: cleanText(el.textContent).replace(/^[A-Z][、.\s]*/, '')
          };
        });

        return {
          id: node.id || ('q_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6)),
          type: type,
          stem: stem.replace(/^第?\s*\d+[\.、\s]+题[\.、:：\s]*/, ''),
          options: options,
          rawHtml: node.outerHTML.slice(0, 4000),
          source: this.getPageInfo()
        };
      } catch (e) {
        return null;
      }
    },

    // ==================== 视频钩子 ====================
    startVideoHook() {
      var self = this;
      var applyToVideo = function(v, label) {
        try {
          // 静音
          if (!v.muted) v.muted = true;

          // 自动播放
          if (v.paused && !v.ended && v.readyState >= 1) {
            if (v._saLastPlay && (Date.now() - v._saLastPlay) < 3000) return;
            v._saLastPlay = Date.now();
            var p = v.play();
            if (p && p.catch) p.catch(function() {});
          }

          // 绑定 ended 事件
          if (!v._saEndBound) {
            v._saEndBound = true;
            v.addEventListener('ended', function() {
              try {
                window.parent.postMessage({
                  source: 'sa-extension',
                  type: 'automation:videoEnded',
                  payload: { label: label }
                }, '*');
              } catch (e) {}
            }, { passive: true });
          }

          // 防暂停
          if (!v._saPauseBound) {
            v._saPauseBound = true;
            v.addEventListener('pause', function() {
              if (!v.ended) {
                setTimeout(function() { v.play().catch(function() {}); }, 500);
              }
            }, { passive: true });
          }
        } catch (e) {}
      };

      var scan = function() {
        document.querySelectorAll('video, audio').forEach(function(v, i) {
          applyToVideo(v, '#' + i);
        });
        try {
          document.querySelectorAll('iframe').forEach(function(f) {
            try {
              var doc = f.contentDocument;
              if (doc) doc.querySelectorAll('video, audio').forEach(function(v, i) {
                applyToVideo(v, 'iframe#' + i);
              });
            } catch (e) {}
          });
        } catch (e) {}
      };

      scan();
      var timer = setInterval(scan, 2000);
      this._pollingTimers.push(timer);
      setTimeout(function() {
        clearInterval(timer);
        var idx = self._pollingTimers.indexOf(timer);
        if (idx !== -1) self._pollingTimers.splice(idx, 1);
      }, 10 * 60 * 1000);
    },

    // ==================== DOM 观察 ====================
    startObserving() {
      var self = this;
      if (this._observer) this._observer.disconnect();
      var debouncedNotify = global.SADom.debounce(function() {
        // 检测新题目
        if ($$(SEL.questionContainer).length > 0) {
          try { global.SAAdapterEvent && global.SAAdapterEvent('question:detected', {}); } catch (e) {}
        }
        // 检测视频结束
        var v = $(SEL.questionContainer);
      }, 800);
      this._observer = new MutationObserver(debouncedNotify);
      this._observer.observe(document.body, { childList: true, subtree: true });
    },

    // ==================== 自动化动作 ====================
    async runAction(action, args) {
      switch (action) {
        case 'fillAnswer':
          return this._fillAnswer(args.questionId, args.answer);
        case 'clickOption':
          return this._clickOption(args.questionId, args.index);
        case 'submit':
          return this._clickSubmit();
        case 'getTaskStatus':
          return { unfinished: this._getUnfinishedTasks() };
        default:
          return false;
      }
    },

    _fillAnswer(questionId, answer) {
      var node = document.getElementById(questionId) || $('#' + questionId);
      if (!node) return false;
      var opts = $$(SEL.questionOptions, node);
      if (!opts.length) return false;
      if (Array.isArray(answer)) {
        answer.forEach(function(idx) { opts[idx] && opts[idx].click(); });
      } else if (typeof answer === 'number' || /^[A-Z]$/.test(answer)) {
        var idx = typeof answer === 'number' ? answer : answer.charCodeAt(0) - 65;
        if (opts[idx]) opts[idx].click();
      } else {
        var input = node.querySelector('input, textarea, [contenteditable="true"]');
        if (input) {
          input.value = answer;
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
      return true;
    },

    _clickOption(questionId, index) {
      var node = document.getElementById(questionId) || $('#' + questionId);
      if (!node) return false;
      var opt = $$(SEL.questionOptions, node)[index];
      if (opt) { opt.click(); return true; }
      return false;
    },

    _clickSubmit() {
      var btn = $('.Zy_bottom .btn, .submit-btn, .btn-submit, [type="submit"]');
      if (btn) { btn.click(); return true; }
      return false;
    },

    // ==================== 获取未完成任务 ====================
    _getUnfinishedTasks() {
      var mArg = this._getMArg();
      if (!mArg || !mArg.attachments) return [];
      var unfinished = [];
      mArg.attachments.forEach(function(att) {
        if (att.job === true && !att.isPassed) {
          var jid = (att.property && att.property.jobid) ? att.property.jobid : att.jobid;
          if (jid) unfinished.push({ jobId: String(jid), type: att.type || 'unknown' });
        }
      });
      return unfinished;
    },

    _getMArg() {
      try {
        var scripts = document.querySelectorAll('script');
        for (var i = 0; i < scripts.length; i++) {
          var text = scripts[i].textContent;
          if (!text || !text.includes('mArg')) continue;
          var match = text.match(/try\s*\{\s*mArg\s*=\s*(\{[\s\S]+?\});\s*\}\s*catch/) ||
                      text.match(/mArg\s*=\s*(\{[\s\S]+?\});/);
          if (match) {
            try { return JSON.parse(match[1]); } catch (e) {}
          }
        }
      } catch (e) {}
      return null;
    }
  };

  global.SAChaoxingAdapter = ChaoxingAdapter;
})(typeof self !== 'undefined' ? self : globalThis);
