﻿# 部署指南

> 本文档面向「**零基础 / 想要快速跑起来**」的同学，复制粘贴即可完成。

## 1. 准备图标（必须）

扩展加载前必须有图标，否则 Chrome 会拒绝。两种方式任选其一：

### 方式 A：用任意 PNG 占位
准备 4 张 PNG，尺寸分别为`16 / 32 / 48 / 128`，放到：

```
src/assets/icons/icon16.png
src/assets/icons/icon32.png
src/assets/icons/icon48.png
src/assets/icons/icon128.png
```

> 不会做图？用 [favicon.io](https://favicon.io/emoji-favicons/) 选个 智能助手 emoji 生成，然后改后缀复制 4 份即可。

### 方式 B：先临时跑（无图标）
如果你赶时间，先把`manifest.json` 中所有`"default_icon"` 和`action.default_icon` 字段删除，Chrome 会用默认占位图标。

---

## 2. 准备 PDF.js（可选）

PDF 解析依赖 PDF.js。如果不需要解析 PDF，可跳过本节。

```bash
mkdir -p src/assets/pdfjs
cd src/assets/pdfjs
# 下载 PDF.js v4.0.379 预编译版
curl -L -o pdf.min.mjs https://cdn.jsdelivr.net/npm/pdfjs-dist@4.0.379/build/pdf.min.mjs
curl -L -o pdf.worker.min.mjs https://cdn.jsdelivr.net/npm/pdfjs-dist@4.0.379/build/pdf.worker.min.mjs
```

> **注意**：`manifest.json` 已声明`web_accessible_resources` 包含这两个文件，扩展安装后即可访问。

如果不想打包 PDF.js 也可以：代码会自动 fallback 到 CDN（需要联网）。

---

## 3. 加载扩展

### Chrome / Edge 通用步骤
1. 打开`chrome://extensions`（Edge 是`edge://extensions`）
2. 打开右上角 **「开发者模式」** 开关
3. 点 **「加载已解压的扩展程序」**
4. 选择项目根目录（即包含`manifest.json` 的目录）
5. 加载成功后，工具栏会出现 智能助手 图标

### 验证安装
- 点击工具栏图标 → 弹出 Popup → 点「打开侧边栏」
- 访问`https://mooc1.chaoxing.com/`，右下角应出现紫色悬浮球

---

## 4. 模式 B：本地 AI（最简单，推荐先试）

### 4.1 安装 Ollama
- 官网下载：<https://ollama.com/download>
- Windows 装完会自动启动服务（默认`http://localhost:11434`）

### 4.2 拉取模型
```bash
ollama pull qwen2.5:7b
# 或
ollama pull deepseek-r1:7b
```

### 4.3 在扩展中配置
1. 点工具栏 智能助手 → 选「本地 AI」
2. 填：
- Base URL：`http://localhost:11434/v1`
- API Key：`ollama`（任意字符串）
- 模型名：`qwen2.5:7b`
3. 点「测试连接」→ 绿色 [OK] 表示成功
4. 点「保存」

### 4.4 LM Studio
- 启动后默认监听`http://localhost:1234/v1`
- Base URL 改为`http://localhost:1234/v1` 即可

---

## 5. 模式 C：WSL Agent

适合需要更复杂 Agent 能力（多步推理、工具调用、RAG 检索）的场景。

详见 [WSL_AGENT.md](./WSL_AGENT.md)

快速命令：
```bash
# WSL 中
wsl
sudo apt update && sudo apt install python3-pip
pip install fastapi uvicorn pydantic
# 启动
python3 docs/wsl_agent_demo.py
```

Windows 浏览器访问`http://localhost:8787/health` 应当返回 200。

---

## 6. 模式 A：第三方题库

警告 **重要提示**：
- 大学搜题酱 / 作业帮等服务多为**付费 / 校园代理**，请自行购买或使用校园 API
- 本项目仅给出对接框架，**Token 需要你自己获取**
- 不当使用可能违反学校规定，请**仅用于学习**目的

### 获取 Token（以大学搜题酱为例）
1. 微信小程序「大学搜题酱」登录
2. F12 抓包任意接口，从`Authorization: Bearer xxx` 中提取 token
3. 填入扩展设置 → 第三方题库 → Token

---

## 7. 调试技巧

### 查看日志
- Content Script 日志：在目标网页 F12 → Console → 筛选`[SA:`
- Background 日志：`chrome://extensions` → 点扩展「服务工作者」链接 → DevTools
- Side Panel 日志：右键侧边栏 → 「检查」

### 修改代码后热重载
扩展页面点 重新生成 按钮即可（content script 需要刷新目标网页）

---

## 8. 常见问题

| 现象 | 原因 | 解决 |
|---|---|---|
| 加载扩展报`manifest_version` 错误 | Chrome 版本过低 | 升级到 102+ |
| 本地 AI 一直超时 | Ollama 未启动 | 终端`ollama serve` |
| 学习通抓不到题 | DOM 改版 | 编辑`src/content/adapters/chaoxing.js` 的 SELECTORS |
| 悬浮球被遮挡 | 宿主页 z-index 极高 | 改`host.style.zIndex` 为`2147483647` |
| Side Panel 不显示 | 没勾选允许侧边栏 |`chrome://extensions` → 扩展详情 → 站点访问 → 允许 |

---

## 9. 打包发布

```bash
# 在项目根目录
zip -r study-assistant-extension.zip . -x "node_modules/*" "*.md" "docs/*"
```

Chrome 开发者中心：<https://chrome.google.com/webstore/devconsole/>
首次发布需要支付 $5 开发者注册费。

---
