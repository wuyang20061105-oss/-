/**
* 浏览器内 PDF 解析器
*
* 两种触发方式：
* 1. 用户在 PDF 页面（chrome-extension://.../pdf/*.pdf 或 file://*.pdf、https://*.pdf）
* - 通过 chrome.tabs 拿 URL 调 PDF.js 解析
* 2. 用户上传文件（设置面板的 file in put）
* - FileReader -> ArrayBuffer -> PDF.js
*
* 依赖：使用浏览器自带的 PDF.js（chrome:// 资源），无网络依赖
*/
(function (global) {
'use strict';

const log = global.SALogger;

// 动态加载 PDF.js（chrome 内置 / CDN 兜底）
let pdfjsLib =null;
async function ensurePdfjs() {
if (pdfjsLib)return pdfjsLib;
pdfjsLib = await import(chrome.runtime.getURL('src/assets/pdfjs/pdf.min.mjs'));
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('src/assets/pdfjs/pdf.worker.min.mjs');
return pdfjsLib;
}

async function extractFromUrl(url) {
const lib = await ensurePdfjs();
const task = lib.getDocument(url);
const pdf = await task.promise;
return readAllPages(pdf);
}

async function extractFromFile(file) {
const lib = await ensurePdfjs();
const buf = await file.arrayBuffer();
const pdf = await lib.getDocument({ data: buf }).promise;
return readAllPages(pdf);
}

async function readAllPages(pdf) {
const total = pdf.numPages;
const max = Math.min(total, 200); // 防爆炸
const pages = [];
for (let i = 1; i <= max; i++) {
const page = await pdf.getPage(i);
const content = await page.getTextContent();
const text = content.items.map(it => it.str).join(' ');
pages.push({ page: i, text });
}
return {
totalPages: total,
extracted: max,
pages,
fullText: pages.map(p => p.text).join('\n\n')
};
}

/**
* 提取当前 Tab 中的 PDF
* - 如果当前 tab 是 PDF viewer，自动执行
* - 否则通过 chrome.tabs 拿到 URL
*/
async function extractFromCurrentTab() {
// 优先：如果 content script 注入在 PDF 页面，document 自身就是 PDF
if (document.contentType === 'application/pdf' || /\.pdf($|\?)/i.test(location.href)) {
try {
return await extractFromUrl(location.href);
} catch (e) {
log.error('Pdf', 'extract from location failed:', e);
throw e;
}
}
// 退化：通过 background 拿当前 tab URL
const tab = await new Promise(r => chrome.runtime.sendMessage({ type: 'tab:current' },r));
if (!tab?.url) throw new Error('cannot determine current tab url');
return extractFromUrl(tab.url);
}

global.SAPdfExtractor = { extractFromUrl, extractFromFile, extractFromCurrentTab };
})(typeof self !== 'undefined' ? self : globalThis);
