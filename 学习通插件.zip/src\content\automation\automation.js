/**
 * 自动学习主控 (照搬 xuexitong_addon 逻辑)
 *
 * 核心逻辑照搬参考插件：
 * 1. video.js - 视频播放控制
 * 2. doc.js - 文档滚动控制
 * 3. main.js - 任务调度
 */
(function (global) {
  'use strict';

  var IS_TOP = (function() { try { return window.top === window.self; } catch (e) { return true; } })();

  // ==================== 状态管理 ====================
  var State = {
    get: function(cb) {
      if (!chrome.runtime || !chrome.runtime.id) return cb({});
      try { chrome.storage.local.get(null, function(res) { cb(res || {}); }); } catch(e) { cb({}); }
    },
    set: function(data, cb) {
      if (!chrome.runtime || !chrome.runtime.id) return;
      try { chrome.storage.local.set(data, cb); } catch(e) {}
    }
  };

  var KEYS = {
    IS_LEARN_MODE: 'cx_is_learn_mode',
    IS_LEARN_RUNNING: 'cx_learn_run',
    VIDEO_SPEED: 'cx_video_speed'
  };

  // ==================== Toast 通知 ====================
  function toast(msg) {
    window.top.postMessage({ action: 'SHOW_TOAST', msg: msg }, '*');
  }

  // ==================== 顶层监听器 ====================
  if (IS_TOP) {
    window.addEventListener('message', function(e) {
      if (e.data && e.data.action === 'SHOW_TOAST') {
        var toastEl = document.getElementById('cx-toast');
        if (!toastEl) {
          toastEl = document.createElement('div');
          toastEl.id = 'cx-toast';
          toastEl.style.cssText = 'position:fixed;top:15%;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.85);color:#fff;padding:12px 24px;border-radius:8px;z-index:999999999;font-size:14px;pointer-events:none;font-weight:bold;transition:opacity 0.3s;box-shadow:0 4px 10px rgba(0,0,0,0.3);';
          document.body.appendChild(toastEl);
        }
        toastEl.innerText = e.data.msg;
        toastEl.style.display = 'block';
        toastEl.style.opacity = '1';
        setTimeout(function() { if (toastEl.innerText === e.data.msg) toastEl.style.opacity = '0'; }, 3000);
      }

      if (e.data && e.data.action === 'NEXT_CHAPTER') {
        try {
          chrome.runtime.sendMessage({ type: 'override-confirm' });
        } catch(err) {}

        var nextBtn = document.querySelector('.prev_next.next, .nextChapter, #prevNextFocusNext');
        if (!nextBtn) {
          var elements = document.querySelectorAll('span, a, div');
          for (var i = 0; i < elements.length; i++) {
            if (elements[i].innerText && elements[i].innerText.trim() === '下一节' && elements[i].offsetParent !== null) {
              nextBtn = elements[i];
              break;
            }
          }
        }

        if (nextBtn) {
          nextBtn.click();
          var checkCount = 0;
          var checkModal = setInterval(function() {
            checkCount++;
            var confirmBtn = document.querySelector('.layui-layer-btn0, .bluebtn, .sure');
            if (confirmBtn && confirmBtn.offsetParent !== null) {
              confirmBtn.click();
              clearInterval(checkModal);
            }
            if (checkCount > 20) clearInterval(checkModal);
          }, 500);
        } else {
          console.log('[Auto] 未找到下一节按钮，可能是最后一章');
          State.set({ [KEYS.IS_LEARN_RUNNING]: false });
        }
      }
    });
  }

  // ==================== TaskManager (照搬 main.js) ====================
  var TaskManager = {
    isRunning: false,
    tasks: [],
    currentIndex: 0,
    globalSpeed: 2.0,

    start: function(speed) {
      this.isRunning = true;
      this.globalSpeed = speed || 2.0;
      toast('[Auto] 启动刷课，正在解析任务...');
      var self = this;
      setTimeout(function() { self.scanTasks(); }, 2500);
    },

    stop: function() {
      this.isRunning = false;
      toast('[Auto] 已停止自动刷课');
    },

    scanTasks: function() {
      if (!this.isRunning) return;
      this.tasks = [];

      var unfinishedJobIds = [];
      var mArgObj = null;

      // 解析 mArg 获取未完成的任务 ID
      var scripts = document.querySelectorAll('script');
      for (var i = 0; i < scripts.length; i++) {
        var text = scripts[i].textContent;
        if (!text || !text.includes('mArg')) continue;
        
        var match = text.match(/try\s*\{\s*mArg\s*=\s*(\{[\s\S]+?\});\s*\}\s*catch/);
        if (!match) match = text.match(/mArg\s*=\s*(\{[\s\S]+?\});/);
        
        if (match) {
          try {
            mArgObj = JSON.parse(match[1]);
            break;
          } catch(e) {}
        }
      }

      if (mArgObj && mArgObj.attachments) {
        mArgObj.attachments.forEach(function(att) {
          if (att.job === true && !att.isPassed) {
            var jid = (att.property && att.property.jobid) ? att.property.jobid : att.jobid;
            if (jid) unfinishedJobIds.push(String(jid));
          }
        });
      }

      console.log('[Auto] mArg 解析完成，未完成任务数:', unfinishedJobIds.length);

      // 扫描 iframe 任务
      var iframes = document.querySelectorAll('.ans-cc iframe, iframe[module]');
      console.log('[Auto] 扫描到 ' + iframes.length + ' 个任务 iframe');
      
      var self = this;
      iframes.forEach(function(iframe) {
        var dataStr = iframe.getAttribute('data') || '';
        var cleanDataStr = dataStr.replace(/&quot;/g, '"');
        var moduleName = iframe.getAttribute('module') || '';
        var src = iframe.src || '';

        var taskType = 'other';
        if (moduleName.includes('video') || cleanDataStr.includes('video') || src.includes('video')) {
          taskType = 'video';
        } else if (moduleName.includes('doc') || moduleName.includes('pdf') || moduleName.includes('ppt') || cleanDataStr.includes('doc') || cleanDataStr.includes('pdf') || cleanDataStr.includes('.ppt') || cleanDataStr.includes('.pptx')) {
          taskType = 'doc';
        }

        var currentJobId = null;
        try {
          var dataObj = JSON.parse(cleanDataStr);
          var j = dataObj.jobid || dataObj.jobId || dataObj._jobid;
          if (j) currentJobId = String(j);
        } catch(e) {
          var match = cleanDataStr.match(/"_?job[iI]d"\s*:\s*"([^"]+)"/);
          if (match && match[1]) currentJobId = String(match[1]);
        }

        var isUnfinished = false;
        if (mArgObj) {
          isUnfinished = currentJobId && unfinishedJobIds.includes(currentJobId);
        } else {
          isUnfinished = !!currentJobId;
        }

        if (taskType !== 'other' && isUnfinished) {
          if (!self.tasks.find(function(t) { return t.iframe === iframe; })) {
            self.tasks.push({ type: taskType, iframe: iframe, isJob: true });
          }
        }
      });

      if (this.tasks.length > 0) {
        toast('[Auto] 发现 ' + this.tasks.length + ' 个未完成任务');
        this.currentIndex = 0;
        this.runNext();
      } else {
        toast('[Auto] 本页已完成，3秒后跳下一节...');
        setTimeout(function() {
          window.top.postMessage({ action: 'NEXT_CHAPTER' }, '*');
        }, 3000);
      }
    },

    runNext: function() {
      if (!this.isRunning) return;

      if (this.currentIndex >= this.tasks.length) {
        toast('[Auto] 本页任务已全部完成，准备跳下一节...');
        setTimeout(function() {
          window.top.postMessage({ action: 'NEXT_CHAPTER' }, '*');
        }, 2000);
        return;
      }

      var currentTask = this.tasks[this.currentIndex];
      var typeName = currentTask.type === 'video' ? '视频' : '文档/PPT';
      toast('[Auto] 正在处理第 ' + (this.currentIndex + 1) + ' 个任务 (' + typeName + ')...');

      var actionCommand = currentTask.type === 'video' ? 'START_VIDEO' : 'START_DOC';

      var self = this;
      setTimeout(function() {
        if (self.isRunning) {
          try {
            currentTask.iframe.contentWindow.postMessage({
              action: actionCommand,
              speed: self.globalSpeed
            }, '*');
          } catch (e) {
            console.log('[Auto] 发送指令失败:', e);
          }
        }
      }, 1000);
    }
  };

  // 监听任务完成
  window.addEventListener('message', function(event) {
    if (event.data && event.data.action === 'TASK_FINISHED') {
      var typeName = event.data.type === 'video' ? '视频' : '文档/PPT';
      toast('[Auto] ' + typeName + ' 任务完成，2秒后处理下一个...');
      TaskManager.currentIndex++;

      if (TaskManager.isRunning) {
        setTimeout(function() { TaskManager.runNext(); }, 2000);
      }
    }
  });

  // ==================== 全局大循环 (照搬 main.js) ====================
  (function() {
    setInterval(function() {
      State.get(function(memory) {
        if (memory[KEYS.IS_LEARN_MODE] && memory[KEYS.IS_LEARN_RUNNING]) {
          var isCourseFrame = document.querySelector('.ans-cc') !== null;
          if (isCourseFrame && !TaskManager.isRunning) {
            TaskManager.start(memory[KEYS.VIDEO_SPEED] || 2.0);
          }
        } else {
          if (TaskManager.isRunning) TaskManager.stop();
        }
      });
    }, 2000);
  })();

  // ==================== AI 答题监控 ====================
  (function() {
    // 启动 AI 答题模块
    if (global.SAAISolver) {
      global.SAAISolver.start();
    }
  })();

  // ==================== 暴露接口 ====================
  global.SAAutomation = {
    state: {
      enabled: false,
      running: false,
      video: { autoPlay: true, mute: true, rate: 2.0 },
      stats: { videoWatched: 0, chaptersDone: 0 }
    },
    start: function() {
      State.set({ [KEYS.IS_LEARN_MODE]: true, [KEYS.IS_LEARN_RUNNING]: true, [KEYS.VIDEO_SPEED]: 2.0 });
      toast('[Auto] 自动刷课已开启');
    },
    stop: function() {
      State.set({ [KEYS.IS_LEARN_RUNNING]: false });
      toast('[Auto] 自动刷课已关闭');
    },
    toggle: function() {
      var self = this;
      State.get(function(memory) {
        if (memory[KEYS.IS_LEARN_RUNNING]) {
          self.stop();
        } else {
          self.start();
        }
      });
    },
    getPublicState: function() {
      return {
        enabled: TaskManager.isRunning,
        running: TaskManager.isRunning,
        stats: {
          videoWatched: TaskManager.currentIndex,
          chaptersDone: 0
        }
      };
    },
    bootstrap: function() {
      console.log('[Auto] 自动学习模块已加载');
      return Promise.resolve();
    }
  };

})(typeof self !== 'undefined' ? self : globalThis);
