/**
 * 设置页逻辑
 *  - 侧边导航 + 内容区
 *  - 加载/保存配置
 *  - 测试连接
 */
(function () {
'use strict';

const $ = id => document.getElementById(id);
const $$ = sel => Array.from(document.querySelectorAll(sel));

const SECTION_TITLES = {
mode: { title: '解答模式', sub: '选择你偏好的 AI 后端' },
thirdparty: { title: '第三方题库', sub: '配置大学搜题酱 / 作业帮等' },
local: { title: '本地 AI', sub: 'Ollama / LM Studio / vLLM' },
wsl: { title: 'WSL Agent', sub: '调用 WSL 内部署的 Agent' },
ui: { title: '界面与自动化', sub: 'UI 行为与刷课自动化' },
cloud: { title: '云端 AI', sub: 'OpenAI 兼容 API 配置' }
};

init().catch(err => {
console.error(err);
showMsg('初始化失败：' + err.message, 'err');
});

async function init() {
const cfg = await self.SAStorage.getConfig();
fillForm(cfg);
bindEvents();
navigateTo('mode');
}

function bindEvents() {
// 侧边导航
$$('.sb-link').forEach(link => {
link.addEventListener('click', e => {
e.preventDefault();
navigateTo(link.dataset.section);
});
});

// 模式单选 → 同步
$$('input[name="mode"]').forEach(r => {
r.addEventListener('change', e => {
if (e.target.checked) {
$$('input[name="mode"]').forEach(x => x !== e.target && (x.checked = false));
}
});
});

// 保存
$('btnSave').onclick = onSave;
$('btnCancel').onclick = async () => {
const cfg = await self.SAStorage.getConfig();
fillForm(cfg);
showMsg('已撤销修改', 'info');
};

// 重置
$('btnReset').onclick = async () => {
if (!confirm('确认恢复默认配置？此操作不可撤销。')) return;
const def = await self.SAStorage.resetConfig();
fillForm(def);
showMsg('已恢复默认', 'ok');
};

// 列出本地模型
$('btnFetchModels').onclick = onFetchModels;

// 测试连接
$$('.btn-test').forEach(btn => {
btn.onclick = () => onTest(btn.dataset.test);
});
}

function navigateTo(section) {
$$('.sb-link').forEach(l => l.classList.toggle('active', l.dataset.section === section));
$$('.sec').forEach(s => s.classList.toggle('active', s.id === 'sec-' + section));
const meta = SECTION_TITLES[section];
if (meta) {
$('sectionTitle').textContent = meta.title;
$('sectionSub').textContent = meta.sub;
}
}

function fillForm(cfg) {
// 模式
$$('input[name="mode"]').forEach(r => r.checked = (r.value === cfg.mode));

// 第三方
$('tp-provider').value = cfg.thirdparty.provider;
$('tp-token').value = cfg.thirdparty.token || '';
$('tp-cookie').value = cfg.thirdparty.cookie || '';
$('tp-endpoint').value = cfg.thirdparty.endpoint;

// 本地
$('local-base').value = cfg.local.baseUrl;
$('local-key').value = cfg.local.apiKey || '';
$('local-model').value = cfg.local.model || '';
$('local-temp').value = cfg.local.temperature;
$('local-max').value = cfg.local.maxTokens;
$('local-sys').value = cfg.local.systemPrompt || '';

// WSL
$('wsl-base').value = cfg.wsl.baseUrl;
$('wsl-key').value = cfg.wsl.apiKey || '';
$('wsl-agent').value = cfg.wsl.agentName || '';
$('wsl-timeout').value = cfg.wsl.timeoutMs;

// UI
$('ui-autoopen').checked = !!cfg.ui.autoOpen;
$('ui-ball').checked = !!cfg.ui.showFloatingBall;
$('ui-pos').value = cfg.ui.ballPosition || 'right-middle';

  // 自动化
  $('auto-video').checked = !!cfg.automation.autoSkipVideo;
  $('auto-rate').value = cfg.automation.playRate || 1;
  if ($('auto-mute')) $('auto-mute').checked = cfg.automation.muteVideo !== false;
  $('auto-quiz').checked = !!cfg.automation.autoAnswer;
  $('auto-submit').checked = !!cfg.automation.autoSubmit;

  // 云端 AI
  $('cloud-base').value = cfg.cloud.baseUrl;
  $('cloud-key').value = cfg.cloud.apiKey || '';
  $('cloud-model').value = cfg.cloud.model || '';
  $('cloud-temp').value = cfg.cloud.temperature;
  $('cloud-max').value = cfg.cloud.maxTokens;
  $('cloud-sys').value = cfg.cloud.systemPrompt || '';
}

function collectForm(current) {
const modeRadio = $$('input[name="mode"]').find(r => r.checked);
return {
mode: modeRadio?.value || current.mode,
thirdparty: {
provider: $('tp-provider').value,
token: $('tp-token').value.trim(),
cookie: $('tp-cookie').value.trim(),
endpoint: $('tp-endpoint').value.trim()
},
local: {
baseUrl: $('local-base').value.trim(),
apiKey: $('local-key').value.trim(),
model: $('local-model').value.trim(),
temperature: Number($('local-temp').value) || 0.2,
maxTokens: Number($('local-max').value) || 2048,
systemPrompt: $('local-sys').value
},
wsl: {
baseUrl: $('wsl-base').value.trim(),
apiKey: $('wsl-key').value.trim(),
agentName: $('wsl-agent').value.trim(),
timeoutMs: Number($('wsl-timeout').value) || 60000
},
ui: {
autoOpen: $('ui-autoopen').checked,
showFloatingBall: $('ui-ball').checked,
ballPosition: $('ui-pos').value
},
  automation: {
    autoSkipVideo: $('auto-video').checked,
    muteVideo: $('auto-mute')?.checked ?? true,
    playRate: Number($('auto-rate').value) || 1,
    autoAnswer: $('auto-quiz').checked,
    autoSubmit: $('auto-submit').checked
  },
  cloud: {
    baseUrl: $('cloud-base').value.trim(),
    apiKey: $('cloud-key').value.trim(),
    model: $('cloud-model').value.trim(),
    temperature: Number($('cloud-temp').value) || 0.2,
    maxTokens: Number($('cloud-max').value) || 2048,
    systemPrompt: $('cloud-sys').value
  }
};
}

async function onSave() {
const cur = await self.SAStorage.getConfig();
const next = collectForm(cur);
await self.SAStorage.setConfig(next);
showMsg('已保存', 'ok');
}

async function onTest(mode) {
const cur = await self.SAStorage.getConfig();
const cfg = collectForm(cur)[mode];
showMsg(`正在测试 ${mode}…`, 'info');
try {
  if (mode === 'local') await testLocal(cfg);
  else if (mode === 'wsl') await testWsl(cfg);
  else if (mode === 'thirdparty') await testThirdparty(cfg);
  else if (mode === 'cloud') await testCloud(cfg);
  showMsg(`${mode} 连接成功`, 'ok');
} catch (e) {
showMsg(mode + ' 失败：' + e.message, 'err');
}
}

async function testLocal(cfg) {
const res = await fetch(cfg.baseUrl.replace(/\/+$/, '') + '/models', {
headers: { 'Authorization': 'Bearer ' + cfg.apiKey }
});
if (!res.ok) throw new Error('HTTP ' + res.status);
const data = await res.json();
const n = (data.data || []).length;
showMsg('连接成功，发现 ' + n + ' 个模型', 'ok');
}

async function testWsl(cfg) {
const res = await fetch(cfg.baseUrl.replace(/\/+$/, '') + '/health', {
headers: cfg.apiKey ? { 'Authorization': 'Bearer ' + cfg.apiKey } : {}
});
if (!res.ok) throw new Error('HTTP ' + res.status);
}

async function testThirdparty(_cfg) {
  if (!_cfg.endpoint) throw new Error('接口地址未填');
  if (!_cfg.token) throw new Error('Token 未填');
  showMsg('配置已就绪（实际抓取需联网）', 'ok');
}

async function testCloud(cfg) {
  const res = await fetch(cfg.baseUrl.replace(/\/+$/, '') + '/models', {
    headers: { 'Authorization': 'Bearer ' + cfg.apiKey }
  });
  if (!res.ok) {
    if (res.status === 401 || res.status === 403) throw new Error('认证失败，请检查密钥');
    if (res.status === 404) {
      showMsg('连接成功（不暴露模型列表）', 'ok');
      return;
    }
    throw new Error('HTTP ' + res.status);
  }
  const data = await res.json();
  const n = (data.data || []).length;
  showMsg('连接成功，发现 ' + n + ' 个模型', 'ok');
}

async function onFetchModels() {
const cur = await self.SAStorage.getConfig();
const cfg = collectForm(cur).local;
try {
const res = await fetch(cfg.baseUrl.replace(/\/+$/, '') + '/models', {
headers: { 'Authorization': 'Bearer ' + cfg.apiKey }
});
if (!res.ok) throw new Error('HTTP ' + res.status);
const data = await res.json();
const models = (data.data || []).map(m => m.id);
if (!models.length) return showMsg('未发现模型，请先 ollama pull', 'err');
const pick = prompt('本地 ' + models.length + ' 个模型，请输入要使用的模型名：\n\n' + models.join('\n'), models[0]);
if (pick) $('local-model').value = pick.trim();
} catch (e) {
showMsg('获取模型失败：' + e.message, 'err');
}
}

function showMsg(text, type = 'info') {
const el = $('msg');
el.textContent = text;
  el.className = 'toast ' + type;
el.hidden = false;
clearTimeout(showMsg._t);
showMsg._t = setTimeout(() => { el.hidden = true; }, 3000);
}
})();
