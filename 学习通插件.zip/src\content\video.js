// video.js - 视频播放控制 (照搬 xuexitong_addon)
(function() {
  if (window.__cx_video_loaded__) return;
  window.__cx_video_loaded__ = true;
  console.log("[Video] 视频模块已挂载");

  var VideoWorker = {
      isFinished: false,

      play: function(speed) {
          speed = speed || 2.0;
          if (this.isFinished) return;

          var video = document.querySelector('video') || document.querySelector('.vjs-tech');

          if (!video) {
              console.log("[Video] 视频元素还在加载中，1秒后重试...");
              var self = this;
              setTimeout(function() { self.play(speed); }, 1000);
              return;
          }

          if (!video.dataset.binded) {
              video.dataset.binded = "true";
              var self = this;

              video.addEventListener('ended', function() {
                  console.log("[Video] 视频播放完毕");
                  self.isFinished = true;
                  window.parent.postMessage({ action: "TASK_FINISHED", type: "video" }, '*');
              });

              video.addEventListener('pause', function() {
                  if (!video.ended && !self.isFinished) {
                      setTimeout(function() { video.play(); }, 500);
                  }
              });
          }

          video.muted = true;
          video.playbackRate = speed;

          if (video.paused && !video.ended) {
              video.play().catch(function(e) { console.log("[Video] 播放被拦截", e); });
          }
      }
  };

  window.addEventListener('message', function(event) {
      if (event.data && event.data.action === 'START_VIDEO') {
          VideoWorker.play(event.data.speed || 2.0);
      }
  });
})();
