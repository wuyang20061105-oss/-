/**
 * DOM 工具集
 */
(function (global) {
  'use strict';

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function $$(selector, root) {
    return Array.from((root || document).querySelectorAll(selector));
  }

  function waitFor(selector, opts) {
    opts = opts || {};
    var timeout = opts.timeout || 10000;
    var root = opts.root || document;
    var interval = opts.interval || 200;
    return new Promise(function(resolve, reject) {
      var found = root.querySelector(selector);
      if (found) return resolve(found);
      var t0 = Date.now();
      var timer = setInterval(function() {
        var el = root.querySelector(selector);
        if (el) { clearInterval(timer); resolve(el); }
        else if (Date.now() - t0 > timeout) { clearInterval(timer); reject(new Error('waitFor ' + selector + ' timeout')); }
      }, interval);
    });
  }

  function debounce(fn, wait) {
    wait = wait || 300;
    var timer = null;
    return function() {
      var args = arguments, ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function() { fn.apply(ctx, args); }, wait);
    };
  }

  function cleanText(s) {
    return (s || '').replace(/\s+/g, ' ').trim();
  }

  global.SADom = { $: $, $$: $$, waitFor: waitFor, debounce: debounce, cleanText: cleanText };
})(typeof self !== 'undefined' ? self : globalThis);
