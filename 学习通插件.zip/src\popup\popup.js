(function () {
'use strict';

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

const MODE_LABEL = { thirdparty: '题库', local: '本地 AI', wsl: 'WSL Agent' };

async function init() {
  const cfg = await self.SAStorage.getConfig();
  applyMode(cfg.mode || 'local');
  // 统一开关：只要 autoSkipVideo 或 autoAnswer 为 true 就视为开启
  const isAuto = !!(cfg.automation?.autoSkipVideo || cfg.automation?.autoAnswer);
  $('#autoStudy').checked = isAuto;
  bindEvents();
  showPageHost();
}

function applyMode(mode) {
  $$('.mode').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
}

function bindEvents() {
  $$('.mode').forEach(b => {
    b.addEventListener('click', async () => {
      const mode = b.dataset.mode;
      applyMode(mode);
      await self.SAStorage.setConfig({ mode });
      $('#phSub').textContent = '已切换到 ' + MODE_LABEL[mode];
    });
  });

  // 统一自动学习开关
  $('#autoStudy').addEventListener('change', async e => {
    const cfg = await self.SAStorage.getConfig();
    const enabled = e.target.checked;
    cfg.automation = {
      ...cfg.automation,
      autoSkipVideo: enabled
    };
    await self.SAStorage.setConfig({ automation: cfg.automation });
    // 通知 content script
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab?.id) {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: 'automation:toggle', payload: { enabled } });
        } catch (err1) {
          await new Promise(r => setTimeout(r, 300));
          try { await chrome.tabs.sendMessage(tab.id, { type: 'automation:toggle', payload: { enabled } }); }
          catch (err2) { /* ignore */ }
        }
      }
    } catch (err) {}
    $('#phSub').textContent = enabled ? '自动学习已启动' : '自动学习已停止';
  });

  $('#btnOpen').addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab) { await chrome.sidePanel.open({ tabId: tab.id }); window.close(); }
    } catch (e) { chrome.runtime.openOptionsPage?.(); }
  });

  $('#btnSettings').addEventListener('click', () => {
    chrome.runtime.openOptionsPage?.();
  });
}

async function showPageHost() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab) {
      const host = (new URL(tab.url || 'about:blank')).hostname;
      $('#pageHost').textContent = host || '当前页';
    } else $('#pageHost').textContent = '未连接';
  } catch (e) { $('#pageHost').textContent = '未连接'; }
}

document.addEventListener('DOMContentLoaded', init);
})();
